﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        #region Database connection string
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";
        #endregion

        // Setting up global variables
        string sBranchName;
        string sBranchID;
        string sUsername;
        string sPassword;
        string accesstype;
        string accessSelection;
        string button;
        string message = "";
        string user;

        // Loading the information from the previous pages and when the page refreshes after an event occured
        protected void Page_Load(object sender, EventArgs e)
        {
            txtUsername.Text = "";
            lblError.Text = "";
            try
            {
                sBranchName = Session["branchName"].ToString();
                sBranchID = Session["branchID"].ToString();
                button = Session["button"].ToString();
                sUsername = Session["username"].ToString();
                sPassword = Session["password"].ToString();
                accesstype = Session["Access"].ToString();               

                if (accesstype == "Administrator")
                {
                    ddlAccess.Enabled = true;
                    ddlBranch.SelectedValue = sBranchName;
                    ddlBranch_SelectedIndexChanged(sender, e);
                    ddlBranch.Enabled = false;
                    btnAddEmp.Enabled = false;
                }
                else if (accesstype == "Manager")
                {
                    ddlAccess.Enabled = true;
                    btnGenerate.Enabled = true;
                    ddlBranch.SelectedValue = sBranchName;
                    ddlBranch_SelectedIndexChanged(sender, e);
                    ddlBranch.Enabled = false;
                    btnAddEmp.Enabled = false;
                }
                else if (accesstype == "Sales Clerk")
                {
                    btnUpdate_Click(sender, e);
                }

                try
                {
                    accessSelection = Session["accessSelect"].ToString();
                }
                catch (Exception)
                {
                    // no error
                }

                try
                {
                    user = Session["User"].ToString();
                    txtUsername.Text = user;
                }
                catch (Exception)
                {
                    // no error
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString();
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Session["User"] = "";
            Session["branchName"] = sBranchName;
            Session["branchID"] = sBranchID;
            Session["password"] = sPassword;
            Session["username"] = sUsername;
            Session["access"] = accesstype;
            Session["button"] = button;
            Server.Transfer("~/Selection.aspx");
            Response.Redirect("Selection.aspx");
        }

        protected void btnAddEmp_Click(object sender, EventArgs e)
        {
            #region CheckEmpty
            if (ddlAccess.SelectedItem.ToString() == "-Select Access Type-")
            {
                lblError.Text = "Please select a Access type";
            }
            else if (ddlBranch.SelectedItem.ToString() == "-Select Branch-")
            {
                lblError.Text = "Please select a Branch";
            }
            else if (txtName.Text == "")
            {
                lblError.Text = "Please enter employee Name";
            }
            else if (txtSurname.Text == "")
            {
                lblError.Text = "Please enter employee Surname";
            }
            else if (txtCell.Text == "")
            {
                lblError.Text = "Please enter employee cellphone number";
            }
            else if (txtPassword.Text == "")
            {
                lblError.Text = "Please enter a password";
            }
            else if (txtPasswordCon.Text == "")
            {
                lblError.Text = "Please confirm employee password";
            }
            else if (txtPassword.Text != txtPasswordCon.Text)
            {
                lblError.Text = "Passwords does not mach";
            }
            else if (txtUsername.Text == "")
            {
                lblError.Text = "Please click 'Generate Username'";
            }
            #endregion
            else 
            {
                if (ddlAccess.SelectedItem.ToString() == "Sales Clerk")
                {
                    bool manage = false;
                    #region try to add a sales clerk
                    try
                    {                        
                        // Connecting to the database using the database connection string
                        MySqlConnection myConn = new MySqlConnection(connection);
                        // The Select statement
                        MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.employees WHERE empAccessType='Manager' AND branchID='" + sBranchID + "';", myConn);
                        // Enableing the application to retreve data from the database
                        MySqlDataReader myReader;
                        // The connection is opened
                        myConn.Open();
                        myReader = SelectCommand.ExecuteReader();

                        while (myReader.Read())
                        {
                            manage = true;
                        }
                        myConn.Close();
                    }
                    catch (Exception ex)
                    {
                        lblError.Text = ex.Message.ToString() + ", please try again";
                        txtPassword.Text = "";
                        txtCell.Text = "";
                        txtPasswordCon.Text = "";
                        txtName.Text = "";
                        txtSurname.Text = "";
                        txtUsername.Text = "";
                        ddlAccess.SelectedIndex = 0;
                    }
                    #endregion

                    #region Add Sales Clerk
                    if (manage == true)
                    {
                        lblError.Text = "";
                        message = "Add Employee";
                        EmployeeClass emp = new EmployeeClass(message, txtUsername.Text, sBranchID, accessSelection, txtName.Text, txtSurname.Text, txtCell.Text, txtPassword.Text, txtPassword.Text, txtPasswordCon.Text);
                        message = emp.Messages.ToString();
                        if (message == "Error: User does exist")
                        {
                            lblError.Text = message + ", please try again";
                            txtPassword.Text = "";
                            txtCell.Text = "";
                            txtPasswordCon.Text = "";
                            txtName.Text = "";
                            txtSurname.Text = "";
                            txtUsername.Text = "";
                            ddlAccess.SelectedIndex = 0;
                        }
                        else if (message == "Done")
                        {
                            lblError.Text = "User sucsessfully added with the username: " + txtUsername.Text;
                            txtPassword.Text = "";
                            txtCell.Text = "";
                            txtPasswordCon.Text = "";
                            txtName.Text = "";
                            txtSurname.Text = "";
                            txtUsername.Text = "";
                            ddlAccess.SelectedIndex = 0;
                        }
                        else
                        {
                            lblError.Text = message + ", please try again";
                            txtPassword.Text = "";
                            txtCell.Text = "";
                            txtPasswordCon.Text = "";
                            txtName.Text = "";
                            txtSurname.Text = "";
                            txtUsername.Text = "";
                            ddlAccess.SelectedIndex = 0;
                        }
                    }
                    else
                    {
                        lblError.Text = "A Sales Clerk cannot be added to a branch that doesn't have a Manager, please try again";
                        txtPassword.Text = "";
                        txtCell.Text = "";
                        txtPasswordCon.Text = "";
                        txtName.Text = "";
                        txtSurname.Text = "";
                        txtUsername.Text = "";
                        ddlAccess.SelectedIndex = 0;
                    }
                    #endregion
                }
                else
                {
                    #region Add employee
                    lblError.Text = "";
                    message = "Add Employee";
                    EmployeeClass emp = new EmployeeClass(message, txtUsername.Text, sBranchID, accessSelection, txtName.Text, txtSurname.Text, txtCell.Text, txtPassword.Text, txtPassword.Text, txtPasswordCon.Text);
                    message = emp.Messages.ToString();
                    if (message == "Error: User does exist")
                    {
                        lblError.Text = message + ", please try again";
                        txtPassword.Text = "";
                        txtCell.Text = "";
                        txtPasswordCon.Text = "";
                        txtName.Text = "";
                        txtSurname.Text = "";
                        txtUsername.Text = "";
                        Session["User"] = "";
                        ddlAccess.SelectedIndex = 0;
                    }
                    else if (message == "Done")
                    {
                        lblError.Text = "User sucsessfully added with the username: " + txtUsername.Text;
                        txtPassword.Text = "";
                        txtCell.Text = "";
                        txtPasswordCon.Text = "";
                        txtName.Text = "";
                        txtSurname.Text = "";
                        txtUsername.Text = "";
                        ddlAccess.SelectedIndex = 0;
                    }
                    else
                    {
                        lblError.Text = message + ", please try again";
                        txtPassword.Text = "";
                        txtCell.Text = "";
                        txtPasswordCon.Text = "";
                        txtName.Text = "";
                        txtSurname.Text = "";
                        txtUsername.Text = "";
                        ddlAccess.SelectedIndex = 0;
                    }
                    #endregion
                }
            }
        }

        protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlBranch.SelectedItem.ToString() == "-Select Branch-")
            {
                btnAddEmp.Enabled = false;
            }
            else
            {
                btnAddEmp.Enabled = true;
            }
        }

        protected void ddlAccess_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            accessSelection = ddlAccess.SelectedItem.ToString();
            if (ddlAccess.SelectedItem.ToString() == "-Select Access Type-")
            {
                Session["accessSelect"] = accessSelection;
                btnAddEmp.Enabled = false;
            }
            else
            {
                if (accesstype == "Administrator")
                {
                    Session["accessSelect"] = accessSelection;
                    btnAddEmp.Enabled = true;
                }
                else if (accesstype == "Manager")
                {
                    if (accessSelection == "Administrator")
                    {
                        lblError.Text = " A Manager cannot add an Administrator, please select an other access type";
                        ddlAccess.SelectedIndex = 0;
                        btnAddEmp.Enabled = false;
                    }
                    else if (accessSelection == "Manager")
                    {
                        lblError.Text = "A Manager cannot add another Manager, please select an other access type";
                        ddlAccess.SelectedIndex = 0;
                        btnAddEmp.Enabled = false;
                    }
                    else
                    {
                        Session["accessSelect"] = accessSelection;
                        btnAddEmp.Enabled = true;
                    }
                }
                
            }
        }

        protected void btnGenerate_Click(object sender, EventArgs e)
        {
            #region Seting up the Lacal Variables

            int Number, lengthN, lengthS = 0;
            string Initials, lettersName, lettersSurname = "";

            #endregion

            #region Get the Selected Access type
            try
            {
                accessSelection = Session["accessSelect"].ToString();
            }
            catch
            {
                // Ignore error
            }
            #endregion

            #region Check for Empty fields

            if (txtName.Text == "")
            {
                lblError.Text = "Please enter employee Name";
            }
            else if (txtSurname.Text == "")
            {
                lblError.Text = "Please enter employee Surname";
            }
            else if (txtCell.Text == "")
            {
                lblError.Text = "Please enter employee cellphone number";
            }
            else if (txtCell.Text != "")
            {
                bool bError = false;
                string CellNumber = txtCell.Text;
                string cellValue;
                int length = CellNumber.Length;

                #region Test for valid cellphone number
                for (int n = 0; n < length; n++)
                {
                    cellValue = CellNumber[n].ToString();
                    if (CellNumber[0].ToString() == "0")
                    {
                        #region test valid characters
                        switch (cellValue)
                        {
                            case "0":
                                // valid
                                break;
                            case "1":
                                // valid
                                break;
                            case "2":
                                // valid
                                break;
                            case "3":
                                // valid
                                break;
                            case "4":
                                // valid
                                break;
                            case "5":
                                // valid
                                break;
                            case "6":
                                // valid
                                break;
                            case "7":
                                // valid
                                break;
                            case "8":
                                // valid
                                break;
                            case "9":
                                // valid
                                break;
                            default:
                                bError = true;
                                break;
                        }
                        #endregion
                    }
                    else
                    {
                        bError = true;
                    }
                }
                #endregion

                if (bError == false)
                {
                    #region Creating the employeeID that is also the Username
                    ddlBranch_SelectedIndexChanged(sender, e);
                    ddlAccess_SelectedIndexChanged(sender, e);

                    Session["password"] = txtPassword.Text;
                    Session["passwordCon"] = txtPasswordCon.Text;
                    lettersName = txtName.Text;
                    lettersSurname = txtSurname.Text;
                    lettersName = lettersName.ToUpperInvariant();
                    lettersSurname = lettersSurname.ToUpperInvariant();
                    lengthN = lettersName.Length;
                    lengthS = lettersSurname.Length;
                    Initials = lettersName[0].ToString();
                    Initials = Initials + lettersSurname[0].ToString();
                    Initials = Initials + lettersSurname[lengthS - 1].ToString();
                    Random r = new Random();
                    Number = r.Next(999);

                    if ((Number < 10) && (Number == 0))
                    {
                        txtUsername.Text = Initials + "00" + Number.ToString();
                    }
                    else if ((Number < 100) && (Number > 9))
                    {
                        txtUsername.Text = Initials + "0" + Number.ToString();
                    }
                    else
                    {
                        txtUsername.Text = Initials + Number.ToString();
                    }
                    txtUsername.Visible = true;
                    txtPassword.Enabled = true;
                    txtPasswordCon.Enabled = true;
                    Session["User"] = txtUsername.Text;
                    #endregion
                }
                else
                {
                    lblError.Text = "The cellphone number you have entered is invalid, please try again.";
                }    
            }
            #endregion            
        }

        protected void btnDeteleEmp_Click(object sender, EventArgs e)
        {
            try
            {
                //try to redirect to the  delete employee page
                Session["User"] = "";
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/RemoveEmp.aspx");
                Response.Redirect("RemoveEmp.aspx");
            }
            catch (Exception ex)
            {
                //Do nothing
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                //try to redirect to the update personal info page
                Session["User"] = "";
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/UpdateEmp.aspx");
                Response.Redirect("UpdateEmp.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("UpdateEmp.aspx");
            }
        }
    }
}