﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm14 : System.Web.UI.Page
    {
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        string sBranchName;
        string sBranchID;
        string sUsername;
        string sPassword;
        string accesstype;
        string button;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                sBranchName = Session["branchName"].ToString();
                sBranchID = Session["branchID"].ToString();
                sPassword = Session["password"].ToString();
                sUsername = Session["username"].ToString();
                accesstype = Session["access"].ToString();
                button = Session["button"].ToString();
            }
            catch (Exception ex)
            {
                // do nothing
            }
        }

        protected void btnBack_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the employee info page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Selection.aspx");
                Response.Redirect("Selection.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Selection.aspx");
            }
        }
    }
}