﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public class InventoryClass
    {
        #region Database connection string
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";
        #endregion

        #region Global var
        bool exist = false;
        string productCode, productType, productAlbum, productArtist, productReleaseDate, itemGenre, branchID, smessage;
        int quantityAvailable = 0, iProffit;
        decimal itemPrice, itemCostValue;
        #endregion

        // Message log
        public string Messages
        {
            get
            {
                return smessage;
            }
            set
            {
                smessage = value;
            }
        }

        // Adding new stock to inventory
        public void AddItem()
        {
            #region Try to Add a new item
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConne = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand InsertCommand = new MySqlCommand("INSERT INTO pavanicadatabase.product(productCode, productType, productAlbum, productArtist, productReleaseDate, itemGenre, itemPrice, itemCostValue, itemProffitPercentage) VALUES ('" + productCode + "','" + productType + "','" + productAlbum + "','" + productArtist + "','" + productReleaseDate + "','" + itemGenre + "','" + itemPrice + "','" + itemCostValue + "','" + iProffit + "');", myConne);
                MySqlCommand InsertCommandLocal = new MySqlCommand("INSERT INTO pavanicadatabase.localchart(branchID,productCode,Lsold) VALUES ('" + branchID + "','" + productCode + "','" + 0 + "');", myConne);
                MySqlCommand InsertCommandNational = new MySqlCommand("INSERT INTO pavanicadatabase.nationalchart(productCode,Nsold) VALUES ('" + productCode + "','" + 0 + "');", myConne);
                MySqlCommand InsertCommandBranch = new MySqlCommand("INSERT INTO pavanicadatabase.branchproduct(branchID,productCode,quantityAvailable) VALUES ('" + branchID + "','" + productCode + "','" + quantityAvailable + "');", myConne);
                // The connection is opened
                myConne.Open();
                InsertCommand.ExecuteNonQuery();
                InsertCommandLocal.ExecuteNonQuery();
                InsertCommandNational.ExecuteNonQuery();
                InsertCommandBranch.ExecuteNonQuery();                
                smessage = "Done";
                myConne.Close();
            }
            catch (Exception e)
            {
                smessage = e.Message.ToString();
            }
            #endregion

            // Write message to message log
            Messages = smessage;
        }

        // Remove existing stock
        public void RemoveItem()
        {
            #region Try to select and then remove the selected item permanently from all the branches
            try
            {
                exist = false;
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.product WHERE productCode='" + productCode + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    #region Delete Stock
                    // Connecting to the database using the database connection string
                    MySqlConnection myConne = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand DeleteCommand = new MySqlCommand("DELETE FROM pavanicadatabase.product WHERE productCode='" + productCode + "';", myConne);
                    MySqlCommand DeleteCommandLocal = new MySqlCommand("DELETE FROM pavanicadatabase.localchart WHERE productCode='" + productCode + "';", myConne);
                    MySqlCommand DeleteCommandNational = new MySqlCommand("DELETE FROM pavanicadatabase.nationalchart WHERE productCode='" + productCode + "';", myConne);
                    MySqlCommand DeleteCommandSale = new MySqlCommand("DELETE FROM pavanicadatabase.Sales WHERE productCode='" + productCode + "';", myConne);
                    MySqlCommand DeleteCommandBranch = new MySqlCommand("DELETE FROM pavanicadatabase.branchproduct WHERE productCode='" + productCode + "';", myConne);
                    // The connection is opened
                    myConne.Open();
                    DeleteCommandSale.ExecuteNonQuery();
                    DeleteCommandBranch.ExecuteNonQuery();
                    DeleteCommandLocal.ExecuteNonQuery();
                    DeleteCommandNational.ExecuteNonQuery();
                    DeleteCommand.ExecuteNonQuery();
                    myConne.Close();

                    exist = true;
                    smessage = "Done";
                    #endregion
                }
                myConn.Close();
                if (exist == false)
                {
                    smessage = "Error: Product does not exist";
                }
            }
            catch (Exception e)
            {
                smessage = e.Message.ToString();
            }
            #endregion

            //Write message to message log
            Messages = smessage;
        }
        
        // Update Employee information
        public void UpdateItem()
        {
            try
            {
                exist = false;
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.product WHERE productCode='" + productCode + "';", myConn);
                MySqlCommand SelectCommandBranch = new MySqlCommand("SELECT * FROM pavanicadatabase.branchproduct WHERE branchID='" + branchID + "' AND productCode = '" + productCode + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();
                myReader = SelectCommandBranch.ExecuteReader();

                while (myReader.Read())
                {
                    // Connecting to the database using the database connection string
                    MySqlConnection myConne = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand UpdateCommand = new MySqlCommand("UPDATE pavanicadatabase.product SET productType='" + productType + "', productAlbum='" + productAlbum + "', productArtist='" + productArtist + "', productReleaseDate='" + productReleaseDate + "', itemGenre='" + itemGenre + "', itemPrice='" + itemPrice + "', itemCostValue='" + itemCostValue + "', itemProffitPercentage='" + iProffit + "' WHERE productCode='" + productCode + "';", myConne);
                    //The Select statment for branch
                    MySqlCommand UpdateCommandBranch = new MySqlCommand("UPDATE pavanicadatabase.branchproduct SET quantityAvailable='" + quantityAvailable + "' WHERE branchID='" + branchID + "' AND productCode = '" + productCode + "';", myConne);
                    // The connection is opened
                    myConne.Open();
                    UpdateCommandBranch.ExecuteNonQuery();
                    UpdateCommand.ExecuteNonQuery();
                    myConne.Close();

                    exist = true;
                    smessage = "Done";
                }
                myConn.Close();
                if (exist == false)
                {
                    smessage = "Error: Product does not exist";
                }
            }
            catch (Exception e)
            {
                smessage = e.Message.ToString();
            }
        }

        #region Class Constructor
        public InventoryClass()
        {
            smessage = "";
            productCode = "";
            productType = "";
            productAlbum = "";
            productArtist = "";
            productReleaseDate = "";
            quantityAvailable = 0;
            itemGenre = "";
            itemPrice = 0;
            itemCostValue = 0;
            iProffit = 0;
            branchID = "";
        }

        public InventoryClass(string sproductCode, string sproductType, string sproductAlbum, string sproductArtist, string sproductReleaseDate, int iQuantityAvalible, string sitemGenre, decimal sitemPrice, decimal sitemCostValue, int Proffit, string sbranchID, string sMessage)
        {
            productCode = sproductCode;
            productType = sproductType;
            productAlbum = sproductAlbum;
            productArtist = sproductArtist;
            productReleaseDate = sproductReleaseDate;
            quantityAvailable = iQuantityAvalible;
            itemGenre = sitemGenre;
            itemPrice = sitemPrice;
            itemCostValue = sitemCostValue;
            branchID = sbranchID;
            iProffit = Proffit;
          
            if (sMessage == "Add Item")
            {
                AddItem();
            }
            else if (sMessage == "Delete Item")
            {
                RemoveItem();
            }
            else if (sMessage == "Update Item")
            {
                UpdateItem();
            }
            sMessage = smessage;
        }
        #endregion
    }
}