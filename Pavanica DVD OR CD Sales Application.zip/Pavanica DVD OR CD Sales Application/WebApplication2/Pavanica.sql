CREATE DATABASE  IF NOT EXISTS `pavanicadatabase` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pavanicadatabase`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: pavanicadatabase
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branch` (
  `branchID` int(11) NOT NULL AUTO_INCREMENT,
  `branchName` varchar(45) NOT NULL,
  `branchLoaction` varchar(45) NOT NULL,
  PRIMARY KEY (`branchID`),
  UNIQUE KEY `branchID_UNIQUE` (`branchID`),
  UNIQUE KEY `branchLoaction_UNIQUE` (`branchLoaction`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (1,'All','Every Where'),(2,'Cape Town','Cape Town'),(3,'Durban','Durban'),(4,'Johannesburg','Johannesburg'),(5,'Kimberley','Kimberley'),(6,'Nelspruit','Nelspruit'),(7,'Port Elezabeth','Port Elezabeth'),(8,'Potchefstroom','Potchefstroom'),(9,'Pretotia','Pretotia'),(10,'Witbank','Witbank');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch/product`
--

DROP TABLE IF EXISTS `branch/product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branch/product` (
  `branchID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`branchID`,`productID`),
  KEY `productID_idx` (`productID`),
  CONSTRAINT `branchID` FOREIGN KEY (`branchID`) REFERENCES `branch` (`branchID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `productID` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch/product`
--

LOCK TABLES `branch/product` WRITE;
/*!40000 ALTER TABLE `branch/product` DISABLE KEYS */;
/*!40000 ALTER TABLE `branch/product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `empID` int(11) NOT NULL AUTO_INCREMENT,
  `branchID` int(11) NOT NULL,
  `empAccessType` varchar(45) NOT NULL DEFAULT 'Admin',
  `empName` varchar(45) NOT NULL DEFAULT 'Sam',
  `empSurname` varchar(45) NOT NULL DEFAULT 'Hoffman',
  `empCell` varchar(45) DEFAULT NULL,
  `empPassword` varchar(45) NOT NULL,
  PRIMARY KEY (`empID`,`branchID`),
  UNIQUE KEY `empID_UNIQUE` (`empID`),
  UNIQUE KEY `empCell_UNIQUE` (`empCell`),
  KEY `branch_idx` (`branchID`),
  CONSTRAINT `branch` FOREIGN KEY (`branchID`) REFERENCES `branch` (`branchID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES (1,1,'Administrator','Arno','du Toit','0742182261','ArnoP@ssword');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `productID` int(11) NOT NULL,
  `prductType` varchar(45) NOT NULL,
  `productName` varchar(45) NOT NULL,
  `productArtist` varchar(45) NOT NULL,
  `productReleaseDate` date NOT NULL,
  `productPrice` decimal(10,0) NOT NULL,
  `productCostValue` decimal(10,0) NOT NULL,
  `productGenre` varchar(45) NOT NULL,
  PRIMARY KEY (`productID`),
  UNIQUE KEY `productID_UNIQUE` (`productID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'CD','Cross Road','Bon Jovi','1994-10-18',60,20,'Other');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `salesID` int(11) NOT NULL AUTO_INCREMENT,
  `empID` int(11) NOT NULL,
  `saleDate` date NOT NULL,
  `saleTime` time NOT NULL,
  `productValue` decimal(10,0) NOT NULL,
  `productTotal` decimal(10,0) NOT NULL,
  `productVAT` decimal(10,0) NOT NULL,
  `productProffitt` decimal(10,0) NOT NULL,
  PRIMARY KEY (`salesID`,`empID`),
  UNIQUE KEY `salesID_UNIQUE` (`salesID`),
  KEY `empID_idx` (`empID`),
  CONSTRAINT `empID` FOREIGN KEY (`empID`) REFERENCES `employees` (`empID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-04-15  9:57:22
