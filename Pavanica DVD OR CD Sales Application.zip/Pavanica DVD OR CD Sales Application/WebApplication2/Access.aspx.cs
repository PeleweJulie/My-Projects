﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //do nothing
        }

        protected void btnHome_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the home page
                Response.Redirect("Home.aspx");
            }
            catch (Exception ex)
            {
                //do nothing
            }
        }

        protected void btnAdministrator_Click1(object sender, ImageClickEventArgs e)
        {
            try
            {
                // Identifying that the Admin button was clicked
                Session["button"] = "Administrator";
                Server.Transfer("~/Login.aspx");
                Response.Redirect("Login.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Login.aspx");
            }            
        }

        protected void btnManager_Click1(object sender, ImageClickEventArgs e)
        {
            try
            {
                // Identifying that the Manager button was clicked
                Session["button"] = "Manager";
                Server.Transfer("~/Login.aspx");
                Response.Redirect("Login.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Login.aspx");
            }            
        }

        protected void btnSalesClerk_Click1(object sender, ImageClickEventArgs e)
        {
            try
            {
                // Identifying that the Sales Clerk button was clicked
                Session["button"] = "Sales Clerk";
                Server.Transfer("~/Login.aspx");
                Response.Redirect("Login.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Login.aspx");
            }            
        }
    }
}