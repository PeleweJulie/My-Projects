﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm9 : System.Web.UI.Page
    {
        string message = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            //Do nothing
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                //try to derirect to the Access page
                Response.Redirect("Access.aspx");
            }
            catch (Exception ex)
            {
                //Do nothing
            }
        }

        protected void btnChangePass_Click(object sender, EventArgs e)
        {
            if (txtCellno.Text == "")
            {
                lblError.Text = "Please enter your cellphone number";
                btnChangePass.Enabled = false;
            }
            else if (txtUsername1.Text == "")
            {
                lblError.Text = "Please enter your username";
                btnChangePass.Enabled = false;
            }
            else if (txtPassword1.Text == "")
            {
                lblError.Text = "Please enter a password";
                btnChangePass.Enabled = false;
            }
            else if (txtConPassword.Text == "")
            {
                lblError.Text = "Please enter confirm your password";
                btnChangePass.Enabled = false;
            }
            else if (txtPassword1.Text != txtConPassword.Text)
            {
                lblError.Text = "Passwords does not mach";
                btnChangePass.Enabled = false;
            }
            else
            {
                lblError.Text = "";
                btnChangePass.Enabled = true;
                message = "Change password";
                EmployeeClass emp = new EmployeeClass(message, txtUsername1.Text, "", "", "", "", txtCellno.Text, "", txtPassword1.Text, txtConPassword.Text);
                message = emp.Messages.ToString();
                if (message == "Error: User does not exist")
                {
                    lblError.Text = message + ", please try again";
                    txtConPassword.Text = "";
                    txtCellno.Text = "";
                    txtPassword1.Text = "";
                    txtUsername1.Text = "";
                }
                else if (message == "Done")
                {
                    lblError.Text = "Password sucsessfully changed";
                    txtConPassword.Text = "";
                    txtCellno.Text = "";
                    txtPassword1.Text = "";
                    txtUsername1.Text = "";
                }
                else
                {
                    lblError.Text = message + ", please try again";
                    txtConPassword.Text = "";
                    txtCellno.Text = "";
                    txtPassword1.Text = "";
                    txtUsername1.Text = "";
                }
            }
        }
    }
}