﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        string sBranchName;
        string sBranchID;
        string sUsername;
        string sPassword;
        string accesstype;
        string button;
        string smes;
        string sCost;
        string sProf;
        string Time;

        int ProffitPer, Avail, iQuantity = 0;
        decimal dPrice, dCost, dTotal, dTotalProf, dTotalVAT, SubEX = 0;

        bool isEmpty = true;


        public void ConvertTime()
        {
            Time = DateTime.Now.Hour.ToString() + ":" + DateTime.Now.Minute.ToString() + ":" + DateTime.Now.Second.ToString();
        }

        public void Cost(string costp)
        {
            try
            {
                dCost = Convert.ToDecimal(costp);
                dCost = toTwoDecimal(dCost);
            }
            catch (Exception)
            {
                lblError.Text = "The Cost Price is invalid";
            }
        }

        public void Proffit(string proff)
        {
            try
            {
                ProffitPer = Int32.Parse(proff);
            }
            catch (Exception)
            {
                lblError.Text = "The Proffit Percentage is invalid";
            }
        }

        public void GetQuantity()
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.branchproduct WHERE productCode='" + txtItemName.Text + "' AND branchID = '" + sBranchID + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Close();
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    #region Load product information
                    txtAvailable.Text = myReader["quantityAvailable"].ToString();
                    #endregion
                    Available();

                    if (Avail <= 10 && Avail > 0)
                    {
                        lblError.Text = "The Branch is all most out of stock, please purchase new stock";
                    }
                    else if (Avail == 0)
                    {
                        lblError.Text = "The Branch is out of stock, please purchase new stock";
                    }
                }
                myConn.Close();
            }
            catch (Exception)
            {
                // ignore errors
            }
        }

        public void Available()
        {
            try
            {
                Avail = Int32.Parse(txtAvailable.Text);
            }
            catch (Exception)
            {
                lblError.Text = "The Available Quantity is invalid";
            }
        }

        public void Quantity()
        {
            try
            {
                iQuantity = Int32.Parse(txtQuantity.Text);
            }
            catch (Exception)
            {
                lblError.Text = "The Quantity is invalid";
            }
        }

        public void Price()
        {
            CalculateSubIN();
            dPrice = dTotal;
            dPrice = toTwoDecimal(dPrice);
        }

        public void CalculateSubEx()
        {
            Cost(sCost);
            CalculateProf();
            SubEX = dCost + dTotalProf;
            SubEX = toTwoDecimal(SubEX);
        }

        public void CalculateProf()
        {
            Cost(sCost);
            Proffit(sProf);
            decimal proffit = 0;
            proffit = dCost * ProffitPer / 100;
            dTotalProf = proffit;
            dTotalProf = toTwoDecimal(dTotalProf);
        }

        public void CalculateVAT()
        {
            CalculateSubEx();
            decimal VAT = 0;
            VAT = SubEX * 14 / 100;
            dTotalVAT = VAT;
            dTotalVAT = toTwoDecimal(dTotalVAT);
        }

        public void CalculateSubIN()
        {
            CalculateVAT();            
            dTotal = SubEX + dTotalVAT;
            dTotal = toTwoDecimal(dTotal);
        }

        public void ValEmpty(Object sender, EventArgs e)
        {
            isEmpty = false;
            if (txtItemName.Text == "")
            {
                btnSubmitCode_Click(sender, e);
                if (txtItemName.Text == "")
                {
                    isEmpty = true;
                    lblError.Text = "Please enter an Item Code";
                }
                else if (txtQuantity.Text == "")
                {
                    isEmpty = true;
                    lblError.Text = "Please enter a Quantity";
                }
            }
            else if (txtQuantity.Text == "")
            {
                isEmpty = true;
                lblError.Text = "Please enter a Quantity";
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            #region Trying to setup the stock page for the logged in employee
            try
            {
                #region Get information
                sBranchName = Session["branchName"].ToString();
                sBranchID = Session["branchID"].ToString();
                sPassword = Session["password"].ToString();
                sUsername = Session["username"].ToString();
                accesstype = Session["access"].ToString();
                button = Session["button"].ToString();
                #endregion

                lblBranchName.Text = "Branch name: " + sBranchName;
                lblBranchID.Text =   "Branch code: " + sBranchID;
                btnConfirm.Enabled = false;
            }
            catch (Exception)
            {
                // Ignore error
            }
            #endregion
        }

        protected void btnBack_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the selection page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Selection.aspx");
                Response.Redirect("Selection.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Selection.aspx");
            }
        }

        protected void btnConfirm_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                if (txtAvailable.Text == "0")
                {
                    lblError.Text = "The Branch is out of stock, please purchase new stock";
                }
                else
                {
                    Available();
                    Quantity();


                    int Highest = 0;
                    int Current = 1;
                    bool lastselected = false;

                    string date = DateTime.Now.Year.ToString();
                    date = date + "-" + DateTime.Now.Month.ToString();
                    date = date + "-" + DateTime.Now.Day.ToString();

                    #region Try to get last sale
                    try
                    {
                        // Connecting to the database using the database connection string
                        MySqlConnection Conn = new MySqlConnection(connection);
                        // The Select statement
                        MySqlCommand Select = new MySqlCommand("SELECT * FROM pavanicadatabase.sales;", Conn);
                        // Enableing the application to retreve data from the database
                        MySqlDataReader myReader;
                        // The connection is opened
                        Conn.Close();
                        Conn.Open();
                        myReader = Select.ExecuteReader();

                        while (myReader.Read())
                        {
                            Current = Int32.Parse(myReader["salesID"].ToString());
                            if (Current >= Highest)
                            {
                                Highest = Current;
                                lastselected = true;
                            }
                        }
                        Conn.Close();
                    }
                    catch (Exception ex)
                    {
                        lblError.Text = ex.Message.ToString() + ", please try again";
                    }
                    #endregion

                    ConvertTime();

                    if (lastselected == true)
                    {
                        Quantity_Click(sender, e);
                        Highest++;
                        dTotalVAT = dTotalVAT * iQuantity;
                        dTotalProf = dTotalProf * iQuantity;
                        Avail = Avail - iQuantity;
                        CaptuereSale(Highest, txtItemName.Text, date, Time, iQuantity, dTotal, dTotalVAT, dTotalProf, Avail, sBranchID);
                    }
                    else
                    {
                        Quantity_Click(sender, e);
                        dTotalVAT = dTotalVAT * iQuantity;
                        dTotalProf = dTotalProf * iQuantity;
                        Avail = Avail - iQuantity;
                        CaptuereSale(Highest, txtItemName.Text, date, Time, iQuantity, dTotal, dTotalVAT, dTotalProf, Avail, sBranchID);
                    }

                    if (Avail <= 10 && Avail > 0)
                    {
                        lblError.Text = lblError.Text + ".       The Branch is all most out of stock, please purchase new stock";
                    }
                    else if (Avail == 0)
                    {
                        lblError.Text = lblError.Text + ".       The Branch is out of stock, please purchase new stock";
                    }
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString() + ", please try again";
            }
        }

        public void CaptuereSale(int saleID, string productCode, string saleDate, string saleTime, int QuantitySold, decimal saleTotal, decimal totalVAT, decimal totalProffit, int quantityleft, string branchID)
        {
            int count=0;
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection Conn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectL = new MySqlCommand("SELECT * FROM pavanicadatabase.localchart WHERE branchID = '" + branchID + "';", Conn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                Conn.Close();
                Conn.Open();
                myReader = SelectL.ExecuteReader();

                while (myReader.Read())
                {
                    count++;
                    int Lsold = Convert.ToInt32(myReader["Lsold"].ToString());
                    #region try to get national items
                    try
                    {
                        MySqlConnection myConn = new MySqlConnection(connection);
                        // The Select statement
                        MySqlCommand SelectN = new MySqlCommand("SELECT * FROM pavanicadatabase.nationalchart WHERE productCode = '" + productCode + "';", myConn);
                        // Enableing the application to retreve data from the database
                        MySqlDataReader myReaders;
                        // The connection is opened
                        myConn.Close();
                        myConn.Open();
                        myReaders = SelectN.ExecuteReader();

                        while (myReaders.Read())
                        {
                            int Nsold = Convert.ToInt32(myReaders["Nsold"].ToString());
                            Lsold = Lsold + QuantitySold;
                            Nsold = Nsold + QuantitySold;

                            #region Try to Sell an item
                            try
                            {
                                // Connecting to the database using the database connection string
                                MySqlConnection myConne = new MySqlConnection(connection);
                                // The Select statement
                                MySqlCommand InsertCommand = new MySqlCommand("INSERT INTO pavanicadatabase.sales(salesID, branchID, productCode, saleDate, saleTime, quantitySold, saleTotal, totalVAT, totalProffit) VALUES ('" + saleID + "','" + branchID + "','" + productCode + "','" + saleDate + "','" + saleTime + "','" + QuantitySold + "','" + saleTotal + "','" + totalVAT + "','" + totalProffit + "');", myConne);
                                MySqlCommand UpdateCommandBranch = new MySqlCommand("UPDATE pavanicadatabase.branchproduct SET quantityAvailable='" + quantityleft + "' WHERE branchID='" + branchID + "' AND productCode = '" + productCode + "';", myConne);
                                MySqlCommand UpdateCommandLocal = new MySqlCommand("UPDATE pavanicadatabase.localchart SET Lsold='" + Lsold + "' WHERE branchID='" + branchID + "' AND productCode = '" + productCode + "';", myConne);
                                MySqlCommand UpdateCommandNational = new MySqlCommand("UPDATE pavanicadatabase.nationalchart SET Nsold='" + Nsold + "' WHERE productCode = '" + productCode + "';", myConne);
                                // The connection is opened
                                myConne.Close();
                                myConne.Open();
                                InsertCommand.ExecuteNonQuery();
                                UpdateCommandBranch.ExecuteNonQuery();
                                UpdateCommandLocal.ExecuteNonQuery();
                                UpdateCommandNational.ExecuteNonQuery();
                                myConne.Close();

                                lblError.Text = "The sale was successfully";
                                txtItemName.Text = "";
                                txtAlbum.Text = "";
                                txtArtist.Text = "";
                                txtAvailable.Text = "";
                                lblTotal.Text = "";
                                txtPrice.Text = "";
                                txtQuantity.Text = "";
                                txtReleaseDate.Text = "";
                                ddlCatagory.SelectedIndex = 0;
                            }
                            catch (Exception ex)
                            {
                                lblError.Text = ex.Message.ToString() + ", please try again";
                            }
                            #endregion
                        }
                        myConn.Close();
                    }
                    catch (Exception ex)
                    {

                        throw;
                    }
                    #endregion
                    if (lblError.Text == "The sale was successfully")
                    {
                        break;
                    }
                }
                Conn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString() + ", please try again";
           }
        }
        
        protected void btnSubmitCode_Click(object sender, EventArgs e)
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.product WHERE productCode='" + txtItemName.Text + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Close();
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    #region Load product information
                    txtAlbum.Text = myReader["productAlbum"].ToString();
                    txtArtist.Text = myReader["productArtist"].ToString();
                    sCost = myReader["itemCostValue"].ToString();
                    sProf = myReader["itemProffitPercentage"].ToString();
                    Price();
                    txtPrice.Text = dPrice.ToString();
                    txtReleaseDate.Text = myReader["productReleaseDate"].ToString();
                    GetQuantity();
                    ddlCatagory.ClearSelection();
                    ddlCatagory.Items.FindByValue(myReader["productType"].ToString()).Selected = true;
                    #endregion

                    #region Convert date to correct format
                    string Day;
                    string Month;
                    string Year;
                    string totalDate;
                    string value;
                    int length;
                    string date;

                    date = txtReleaseDate.Text;
                    totalDate = date;
                    length = totalDate.Length;
                    for (int n = 0; n < length; n++)
                    {
                        value = date[n].ToString();
                        if (value == "/")
                        {
                            if (n == 1)
                            {
                                totalDate = "0" + totalDate;
                            }
                            else if (n == 3)
                            {
                                totalDate = totalDate.Insert(n, "0");
                            }
                        }
                    }

                    Month = totalDate[0].ToString() + totalDate[1].ToString();
                    Day = totalDate[3].ToString() + totalDate[4].ToString();
                    Year = totalDate[6].ToString() + totalDate[7].ToString() + totalDate[8].ToString() + totalDate[9].ToString();

                    txtReleaseDate.Text = Year + "-" + Month + "-" + Day;
                    #endregion
                }
                myConn.Close();
                btnQuantity.Enabled = true;
            }
            catch (Exception)
            {
                // ignore errors
            }
        }

        protected void Quantity_Click(object sender, EventArgs e)
        {
            Available();
            Quantity();
            if (iQuantity > Avail)
            {
                lblError.Text = "There is not enough stock";
                btnConfirm.Enabled = false;
            }
            else
            {
                lblError.Text = "";
                btnSubmitCode_Click(sender, e);
                CalculateSubIN();
                dTotal = dTotal * iQuantity;
                lblTotal.Text = dTotal.ToString();
                btnConfirm.Enabled = true;
            }
        }

        public decimal toTwoDecimal(decimal number)
        {
            string a = number.ToString();

            int length = a.Length;
            char ch = '.';
            int pos = 0;

            for (int c = 0; c < length; c++)
            {
                string nA = a[c].ToString();
                if (nA == ch.ToString())
                {
                    pos = c;
                    break;
                }
            }

            number = 0;
            string currency = "";
            for (int i = 0; i <= pos + 2; i++)
            {
                currency = currency + a[i].ToString();
            }

            number = Convert.ToDecimal(currency);
            return number;
        }
    }
}