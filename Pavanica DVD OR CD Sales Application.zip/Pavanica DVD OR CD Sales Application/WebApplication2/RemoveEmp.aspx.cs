﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class WebForm10 : System.Web.UI.Page
    {
        // database connection
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        // Global variables
        string sBranchName;
        string sBranchID;
        string sUsername;
        string sPassword;
        string sPass;
        string accesstype;
        string button;
        string message = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                sBranchName = Session["branchName"].ToString();
                sBranchID = Session["branchID"].ToString();
                button = Session["button"].ToString();
                sUsername = Session["username"].ToString();
                sPassword = Session["password"].ToString();
                accesstype = Session["Access"].ToString();

                try
                {
                    sPass = Session["pass"].ToString();
                }
                catch (Exception)
                {
                    // Ignore error
                }
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString();
            }
        }

        protected void btnDeteleEmp_Click(object sender, EventArgs e)
        {
            if (txtCell.Text == "")
            {
                lblError.Text = "Please enter a Cell phone number";
            }
            else if (txtEmpName.Text == "")
            {
                lblError.Text = "Please enter a Username";
            }
            else if (txtPassword.Text == "")
            {
                lblError.Text = "Please enter a Password";
            }
            else if (txtPasswordCon.Text == "")
            {
                lblError.Text = "Please enter Confirm your Password";
            }
            else if (txtPassword.Text != txtPasswordCon.Text)
            {
                lblError.Text = "Passwords does not match";
            }
            else
            {
                pnlBox.Visible = true;
                btnCancel.Visible = false;
                btnDeteleEmp.Visible = false;
                Session["pass"] = txtPassword.Text;
            }
        }

        protected void btnYes_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            #region Try to delete an employee
            try
            {
                sPass = Session["pass"].ToString();
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.employees WHERE empID='" + sUsername + "' AND empPassword='" + sPass + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    if ((myReader["empName"].ToString() == txtEmpName.Text) && (myReader["empCell"].ToString() == txtCell.Text))
                    {
                        #region Cannot delete self
                        lblError.Text = "You cannot delete yourself";
                        txtPassword.Text = "";
                        txtCell.Text = "";
                        txtPasswordCon.Text = "";
                        txtEmpName.Text = "";
                        pnlBox.Visible = false;
                        btnCancel.Visible = true;
                        btnDeteleEmp.Visible = true;
                        #endregion
                    }
                    else if (myReader["empAccessType"].ToString() == "Manager")
                    {
                        #region selecting employee and try to delete them
                        try
                        {
                            // Connecting to the database using the database connection string
                            MySqlConnection Conn = new MySqlConnection(connection);
                            // The Select statement
                            MySqlCommand SelectEmpCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.employees WHERE empName='" + txtEmpName.Text + "' AND empCell='" + txtCell.Text + "';", Conn);
                            // Enableing the application to retreve data from the database
                            MySqlDataReader Reader;
                            // The connection is opened
                            Conn.Open();
                            Reader = SelectEmpCommand.ExecuteReader();

                            while (myReader.Read())
                            {
                                string acc = Reader["empAccessType"].ToString();
                                #region try to delete an employee
                                if (acc == "Administrator")
                                {
                                    #region Try to delete an Administrator
                                    lblError.Text = "Managers cannot delete Administrators";
                                    txtPassword.Text = "";
                                    txtCell.Text = "";
                                    txtPasswordCon.Text = "";
                                    txtEmpName.Text = "";
                                    pnlBox.Visible = false;
                                    btnCancel.Visible = true;
                                    btnDeteleEmp.Visible = true;
                                    #endregion
                                }
                                else if (acc == "Managers")
                                {
                                    #region Try to delete an Manager
                                    lblError.Text = "Managers cannot delete other Managers";
                                    txtPassword.Text = "";
                                    txtCell.Text = "";
                                    txtPasswordCon.Text = "";
                                    txtEmpName.Text = "";
                                    pnlBox.Visible = false;
                                    btnCancel.Visible = true;
                                    btnDeteleEmp.Visible = true;
                                    #endregion
                                }
                                else
                                {
                                    #region Delete employee
                                    message = "Delete Employee";
                                    EmployeeClass emp = new EmployeeClass(message, txtEmpName.Text, "", "", "", "", txtCell.Text, "", "", "");
                                    message = emp.Messages.ToString();
                                    if (message == "Error: User does exist")
                                    {
                                        lblError.Text = message + ", please try again";
                                        txtPassword.Text = "";
                                        txtCell.Text = "";
                                        txtPasswordCon.Text = "";
                                        txtEmpName.Text = "";
                                    }
                                    else if (message == "Done")
                                    {
                                        lblError.Text = "User sucsessfully removed with the username: " + txtEmpName.Text;
                                        txtPassword.Text = "";
                                        txtCell.Text = "";
                                        txtPasswordCon.Text = "";
                                        txtEmpName.Text = "";
                                    }
                                    else
                                    {
                                        lblError.Text = message + ", please try again";
                                        txtPassword.Text = "";
                                        txtCell.Text = "";
                                        txtPasswordCon.Text = "";
                                        txtEmpName.Text = "";
                                    }

                                    pnlBox.Visible = false;
                                    btnCancel.Visible = true;
                                    btnDeteleEmp.Visible = true;
                                    #endregion
                                }
                                #endregion
                            }
                            Conn.Close();
                        }
                        catch (Exception)
                        {
                            #region User does not exist
                            lblError.Text = "The user does not exist, please try again";
                            txtPassword.Text = "";
                            txtCell.Text = "";
                            txtPasswordCon.Text = "";
                            txtEmpName.Text = "";
                            pnlBox.Visible = false;
                            btnCancel.Visible = true;
                            btnDeteleEmp.Visible = true;
                            #endregion
                        }
                        #endregion
                    }
                    else
                    {
                        #region Delete employee
                        message = "Delete Employee";
                        EmployeeClass emp = new EmployeeClass(message, txtEmpName.Text, "", "", "", "", txtCell.Text, "", "", "");
                        message = emp.Messages.ToString();
                        if (message == "Error: User does exist")
                        {
                            lblError.Text = message + ", please try again";
                            txtPassword.Text = "";
                            txtCell.Text = "";
                            txtPasswordCon.Text = "";
                            txtEmpName.Text = "";
                        }
                        else if (message == "Done")
                        {
                            lblError.Text = "User sucsessfully removed with the username: " + txtEmpName.Text;
                            txtPassword.Text = "";
                            txtCell.Text = "";
                            txtPasswordCon.Text = "";
                            txtEmpName.Text = "";
                        }
                        else
                        {
                            lblError.Text = message + ", please try again";
                            txtPassword.Text = "";
                            txtCell.Text = "";
                            txtPasswordCon.Text = "";
                            txtEmpName.Text = "";
                        }

                        pnlBox.Visible = false;
                        btnCancel.Visible = true;
                        btnDeteleEmp.Visible = true;
                        #endregion
                    }
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString() + ", please try again";
            }
            #endregion
        }

        protected void btnNo_Click(object sender, EventArgs e)
        {
            pnlBox.Visible = false;
            btnCancel.Visible = true;
            btnDeteleEmp.Visible = true;
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                //try to redirect to the employee info page
                #region Sending information Back to the Employee information page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/EmployeeInfo.aspx");
                #endregion
                #region Go back to the Employee information page
                Response.Redirect("EmployeeInfo.aspx");
                #endregion
            }
            catch (Exception ex)
            {
                Response.Redirect("EmployeeInfo.aspx");
            }
        }
    }
}