﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public class EmployeeClass
    {
        #region Database connection string
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";
        #endregion

        #region Global var
        bool exist = false;
        string smessage, Username, branch, accesstype, name, surname, cell, oldPassword, newPassword, ConfirmationPassword;
        #endregion

        // Adding a new Employee
        public void AddEmployee()
        {
            string date = DateTime.Now.Year.ToString();
            date = date + "-" + DateTime.Now.Month.ToString();
            date = date + "-" + DateTime.Now.Day.ToString();
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConne = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand InsertCommand = new MySqlCommand("INSERT INTO pavanicadatabase.employees(empID, branchID, empStartdate, empAccessType, empName, empSurname, empCell, empPassword) VALUES ('" + Username + "','" + branch + "','" + date + "','" + accesstype + "','" + name + "','" + surname + "','" + cell + "','" + oldPassword + "');", myConne);
                // The connection is opened
                myConne.Open();
                InsertCommand.ExecuteNonQuery();
                smessage = "Done";
                myConne.Close();
            }
            catch (Exception e)
            {
                smessage = e.Message.ToString();
            }
            Messages = smessage;
        }

        // Remove an existing Employee
        public void RemoveEmployee()
        {
            try
            {
                exist = false;
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.employees WHERE empName='" + Username + "' AND empCell='" + cell + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    // Connecting to the database using the database connection string
                    MySqlConnection myConne = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand DeleteCommand = new MySqlCommand("DELETE FROM pavanicadatabase.employees WHERE empCell='" + cell + "' AND empName='" + Username + "';", myConne);
                    // The connection is opened
                    myConne.Open();
                    DeleteCommand.ExecuteNonQuery();
                    myConne.Close();
                    exist = true;
                    smessage = "Done";
                }
                myConn.Close();
                if (exist == false)
                {
                    smessage = "Error: User does not exist";
                }
            }
            catch (Exception e)
            {
                smessage = e.Message.ToString();
            }
            Messages = smessage;
        }

        // Update Employee information
        public void UpdateEmployee()
        {
            try
            {
                exist = false;
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.employees WHERE empPassword='"+oldPassword+"' AND empID='"+Username+"';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    // Connecting to the database using the database connection string
                    MySqlConnection myConne = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand UpdateCommand = new MySqlCommand("UPDATE pavanicadatabase.employees SET empAccessType='"+accesstype+"',empName='"+name+"', empSurname='"+surname+"', empCell='"+cell+"', empPassword='"+newPassword+"' WHERE empPassword='"+oldPassword+"' AND empID='"+Username+"';", myConne);
                    // The connection is opened
                    myConne.Open();
                    UpdateCommand.ExecuteNonQuery();
                    myConne.Close();
                    exist = true;
                    smessage = "Done";
                }
                myConn.Close();
                if (exist == false)
                {
                    smessage = "Unknown Error occred";
                }
            }
            catch (Exception e)
            {
                smessage = e.Message.ToString();
            }
        }

        // Chang Employee password when they forgot it
        public void ChangePassword()
        {
            try
            {
                exist = false;
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.employees WHERE empCell='"+cell+"' AND empID='"+Username+"';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    // Connecting to the database using the database connection string
                    MySqlConnection myConne = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand UpdateCommand = new MySqlCommand("UPDATE pavanicadatabase.employees SET empPassword='"+ConfirmationPassword+"' WHERE empCell='"+cell+"' AND empID='"+Username+"' ;", myConne);
                    // The connection is opened
                    myConne.Open();
                    UpdateCommand.ExecuteNonQuery();
                    myConne.Close();
                    exist = true;
                    smessage = "Done";
                }
                myConn.Close();
                if (exist == false)
                {
                    smessage = "Error: User does not exist";
                }
            }
            catch (Exception e)
            {
                smessage = e.Message.ToString();
            }
            Messages = smessage;
        }

        // Message log
        public string Messages
        {
            get
            {
                return smessage;
            }
            set
            {
                smessage = value;
            }
        }

        #region Class Constructors
        // setting the defualt values
        public EmployeeClass()
        {
            smessage = "";
            Username = "";
            branch = "";
            accesstype = "";
            name = "";
            surname = "";
            cell = "";
            oldPassword = "";
            newPassword = "";
            ConfirmationPassword = "";
        }

        // Constructor
        public EmployeeClass(string sMessage, string sUsername, string sBranch, string sAccesstype, string sName, string sSurname, string sCell, string sOldPassword, string sNewPassword, string sConfirmationPassword)
        {
            Username = sUsername;
            branch = sBranch;
            accesstype = sAccesstype;
            name = sName;
            surname = sSurname;
            cell = sCell;
            oldPassword = sOldPassword;
            newPassword = sNewPassword;
            ConfirmationPassword = sConfirmationPassword;
            Messages = sMessage;

            if (sMessage == "Change password")
            {                
                ChangePassword();
            }
            else if (sMessage == "Add Employee")
            {
                AddEmployee();
            }
            else if (sMessage == "Delete Employee")
            {
                RemoveEmployee();
            }
            else if (sMessage == "Update Employee")
            {
                UpdateEmployee();
            }
            sMessage = smessage;
        }
        #endregion
    }
}