﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        // Setting up global variables
        string sBranchName;
        string sCorrectBranch;
        string sBranchID;
        string sUsername;
        string sPassword;
        string accesstype;
        string button;
        int countError;

        // Loading the information from the previous pages and when the page refreshes after an event occured
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                button = Session["button"].ToString();

                if (button == "Administrator")
                {
                    lblBranch.Visible = false;
                    ddlBranch.Visible = false;
                    btnLogin.Enabled = true;
                }
                else
                {
                    lblBranch.Visible = true;
                    ddlBranch.Visible = true;
                    btnLogin.Enabled = false;
                }
            }
            catch (Exception)
            {
                // Do nothing
            }
        }

        public void MethLogin()
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectComm = new MySqlCommand("SELECT * FROM pavanicadatabase.branch WHERE branchName='" + sBranchName + "' ;", myConn);
                // Enableing the application to retrieve data from the database
                MySqlDataReader reader;
                // The connection is opened
                myConn.Open();
                reader = SelectComm.ExecuteReader();

                // Reading the selected data in the selected table
                while (reader.Read())
                {
                    // Testing whether the table has some data in it
                    if (reader.HasRows)
                    {
                        if (accesstype == "Manager")
                        {
                            sBranchID = reader["branchID"].ToString();
                            // Testing the emloyees branchID to see if what the User choose is correct
                            if (sCorrectBranch == sBranchID)
                            {
                                // Saving the branch ID to be exported to the next page
                                Session["branchName"] = sBranchName;
                                Session["branchID"] = sBranchID;
                                Session["password"] = txtPassword.Text;
                                Session["username"] = txtUsername.Text;
                                Session["access"] = accesstype;
                                Session["button"] = button;
                                // Transfer the data to the Selection page
                                Server.Transfer("~/Selection.aspx");
                                Response.Redirect("Selection.aspx");
                            }
                            else
                            {
                                // Specifying the error for the error label
                                lblError.Text = "Invalid Branch was selected.";
                            }
                        }
                        else if (accesstype == "Sales Clerk")
                        {
                            sBranchID = reader["branchID"].ToString();
                            // Testing the emloyees branchID to see if what the User choose is correct
                            if (sCorrectBranch == sBranchID)
                            {
                                // Saving the branch ID to be exported to the next page
                                Session["branchName"] = sBranchName;
                                Session["branchID"] = sBranchID;
                                Session["password"] = txtPassword.Text;
                                Session["username"] = txtUsername.Text;
                                Session["access"] = accesstype;
                                Session["button"] = button;
                                // Transfer the data to the Selection page
                                Server.Transfer("~/Selection.aspx");
                                Response.Redirect("Selection.aspx");
                            }
                            else
                            {
                                // Specifying the error for the error label
                                lblError.Text = "Invalid Branch was selected.";
                            }
                        }
                    }
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString();
            }
        }

        public void AccessError()
        {
            if ((button == "Administrator") && (countError < 0))
            {
                // Specifying the error for the error label
                lblError.Text = "Invalid Username or Password for a Administrator";
            }
            else if ((button == "Manager") && (countError < 0))
            {
                // Specifying the error for the error label
                lblError.Text = "Invalid Username or Password for a Manager";
            }
            else if ((button == "Sales Clerk") && (countError < 0))
            {
                // Specifying the error for the error label
                lblError.Text = "Invalid Username or Password for a Sales Clerk";
            }
            countError = 0;
        }

        protected void btnBack_Click1(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the access page
                Response.Redirect("Access.aspx");
            }
            catch (Exception ex)
            {
                //do nothing
            }
        }

        protected void btnLogin_Click1(object sender, ImageClickEventArgs e)
        {
            if (txtUsername.Text == "")
            {
                lblError.Text = "Please enter a Username";
            }
            else if (txtPassword.Text == "")
            {
                lblError.Text = "Please enter a Password";
            }
            else
            {
                lblError.Text = "";
                countError = -1;
                try
                {
                    // Connecting to the database using the database connection string
                    MySqlConnection myConn = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.employees WHERE empID='" + txtUsername.Text + "' AND empPassword='" + txtPassword.Text + "' ;", myConn);
                    // Enableing the application to retreve data from the database
                    MySqlDataReader myReader;
                    // The connection is opened
                    myConn.Open();
                    myReader = SelectCommand.ExecuteReader();

                    // Reading the selected data in the selected table
                    while (myReader.Read())
                    {
                        // Testing whether the table has some data in it
                        if (myReader.HasRows)
                        {
                            // To do data validation
                            countError = 0;
                            sCorrectBranch = myReader["branchID"].ToString();
                            sBranchName = ddlBranch.SelectedItem.ToString();
                            // Reading the employee's access type from the database into a global variable
                            accesstype = myReader["empAccessType"].ToString();
                            // Retreving the access button that was clicked
                            if (accesstype == "Manager" && button == "Manager")
                            {
                                MethLogin();
                            }
                            else if (accesstype == "Sales Clerk" && button == "Sales Clerk")
                            {
                                MethLogin();
                            }
                            else if (accesstype == "Administrator" && button == "Administrator")
                            {
                                Session["password"] = txtPassword.Text;
                                Session["username"] = txtUsername.Text;
                                Session["access"] = accesstype;
                                Session["button"] = button;
                                // Transfer the data to the Selection page
                                Server.Transfer("~/Branch.aspx");
                                Response.Redirect("Branch.aspx");
                            }
                            else
                            {
                                countError--;
                            }
                            AccessError();
                        }
                        else
                        {
                            countError--;
                        }
                    }
                    if (countError < 0)
                    {
                        // Specifying the error for the error label
                        lblError.Text = "Invalid Username or Password";
                    }
                    myConn.Close();
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message.ToString();
                }
            }
        }

        protected void ddlBranch_SelectedIndexChanged1(object sender, EventArgs e)
        {
            sBranchName = ddlBranch.SelectedItem.ToString();
            if (ddlBranch.SelectedItem.ToString() == "-Select Branch-")
            {
                btnLogin.Enabled = false;
            }
            else
            {
                btnLogin.Enabled = true;
            }
        }

        protected void lbtnForgotPassword_Click(object sender, EventArgs e)
        {
            try
            {
                //try to redirect to the forgot password page
                Response.Redirect("ForgotPassword.aspx");
            }
            catch(Exception ex)
            {
                Response.Redirect("ForgotPassword.aspx");
            }
        }
    }
}