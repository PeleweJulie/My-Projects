﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class Logged_in : System.Web.UI.Page
    {
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        string sBranchName;
        string sBranchID;
        string sUsername;
        string sPassword;
        string accesstype;
        string button;
        string smes;
        string AddStockBranchID;
        string prof;

        int iquantity = 0;
        int iproffits = 0;

        decimal dCost = 0;
        decimal dPrice = 0;

        bool isEmpty = true;
        bool Product = false;
        bool Branch = false;

        protected void Page_Load(object sender, EventArgs e)
        {
            #region Trying to setup the stock page for the logged in employee
            try
            {
                #region Get information
                sBranchName = Session["branchName"].ToString();
                sBranchID = Session["branchID"].ToString();
                sPassword = Session["password"].ToString();
                sUsername = Session["username"].ToString();
                accesstype = Session["access"].ToString();
                button = Session["button"].ToString();
                #endregion

                #region Admin setup
                if (accesstype == "Administrator")
                {
                    ddlBranch.ClearSelection();
                    ddlBranch.Items.FindByValue(sBranchName).Selected = true;
                    ddlBranch.Enabled = false;
                    btnRemoveItem.Enabled = true;
                    txtPersentage.Visible = true;
                    btnSave.Visible = true;
                    GetBranchID();
                }
                #endregion
                #region Manager setup
                else if (accesstype == "Manager")
                {

                    ddlBranch.ClearSelection();
                    ddlBranch.Items.FindByValue(sBranchName).Selected = true;
                    ddlBranch.Enabled = false;
                    btnRemoveItem.Enabled = false;
                    txtPersentage.Visible = false;
                    lblProffit.Visible = false;
                    btnSave.Visible = false;
                    GetBranchID();
                }
                #endregion
                #region Sales Clerk setup
                /*else if (accesstype == "Sales Clerk")
                {
                    ddlBranch.ClearSelection();
                    ddlBranch.Items.FindByValue(sBranchName).Selected = true;
                    ddlBranch.Enabled = false;
                    btnRemoveItem.Enabled = false;
                    btnAddItem.Enabled = false;
                    btnUpdate.Enabled = false;
                    txtAlbumName.Enabled = false;
                    txtArtistName.Enabled = false;
                    txtCost.Enabled = false;
                    txtPrice.Enabled = false;
                    txtQuantity.Enabled = false;
                    txtReleaseDate.Enabled = false;
                    ddlCatagory.Enabled = false;
                    ddlGenre.Enabled = false;
                    txtPersentage.Visible = false;
                    btnSave.Visible = false;
                    GetBranchID();
                }*/
                #endregion
            }
            catch (Exception)
            {
                // Ignore error
            }
            #endregion
        }

        protected void btnBack_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the selection page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Selection.aspx");
                Response.Redirect("Selection.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Selection.aspx");
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            GetBranchID();
            lblError.Text = "";
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.product WHERE productCode='" + txtItemName.Text + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Close();
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    #region Load product information
                    txtAlbumName.Text = myReader["productAlbum"].ToString();
                    txtArtistName.Text = myReader["productArtist"].ToString();
                    txtCost.Text = myReader["itemCostValue"].ToString();
                    txtPersentage.Text = myReader["itemProffitPercentage"].ToString();
                    txtReleaseDate.Text = myReader["productReleaseDate"].ToString();
                    txtQuantity.Text = "";
                    ddlCatagory.ClearSelection();
                    ddlCatagory.Items.FindByValue(myReader["productType"].ToString()).Selected = true;
                    ddlGenre.ClearSelection();
                    ddlGenre.Items.FindByValue(myReader["itemGenre"].ToString()).Selected = true;
                    #endregion

                    #region Convert display Date to the correct format
                    string Day;
                    string Month;
                    string Year;
                    string totalDate;
                    string value;
                    int length;

                    totalDate = txtReleaseDate.Text;
                    length = totalDate.Length;
                    for (int n = 0; n < length; n++)
                    {
                        value = txtReleaseDate.Text[n].ToString();
                        if (value == "/")
                        {
                            if (n == 1)
                            {
                                totalDate = "0" + totalDate;
                            }
                            else if (n == 3)
                            {
                                totalDate = totalDate.Insert(n, "0");
                            }
                        }
                    }

                    Month = totalDate[0].ToString() + totalDate[1].ToString();
                    Day = totalDate[3].ToString() + totalDate[4].ToString();
                    Year = totalDate[6].ToString() + totalDate[7].ToString() + totalDate[8].ToString() + totalDate[9].ToString();

                    txtReleaseDate.Text = Year + "-" + Month + "-" + Day;
                    #endregion

                    #region Try to Select item at a Branch
                    try
                    {

                        GetBranchID();
                        MySqlConnection Conn = new MySqlConnection(connection);
                        // The Select statement
                        MySqlCommand Select = new MySqlCommand("SELECT * FROM pavanicadatabase.branchproduct WHERE branchID='" + AddStockBranchID + "' AND productCode='" + txtItemName.Text + "';", Conn);
                        // Enableing the application to retreve data from the database
                        MySqlDataReader Reader;
                        // The connection is opened
                        Conn.Close();
                        Conn.Open();
                        Reader = Select.ExecuteReader();

                        while (Reader.Read())
                        {
                            txtQuantity.Text = Reader["quantityAvailable"].ToString();
                        }
                        Conn.Close();
                    }
                    catch (Exception ex)
                    {
                        lblError.Text = ex.Message.ToString();
                    }
                    #endregion
                }
                myConn.Close();
            }
            catch (Exception)
            {
                // ignore errors
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            GetProffit();
            if (prof != txtPersentage.Text)
            {
                if (txtPersentage.Text == "")
                {
                    try
                    {
                        // Connecting to the database using the database connection string
                        MySqlConnection myConn = new MySqlConnection(connection);
                        // The Select statement
                        MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.product;", myConn);
                        // Enableing the application to retreve data from the database
                        MySqlDataReader myReader;
                        // The connection is opened
                        myConn.Close();
                        myConn.Open();
                        myReader = SelectCommand.ExecuteReader();

                        while (myReader.Read())
                        {
                            txtPersentage.Text = myReader["itemProffitPercentage"].ToString();
                        }
                        myConn.Close();
                    }
                    catch (Exception ex)
                    {
                        lblError.Text = ex.Message.ToString() + ", please try again";
                        isEmpty = true;
                    }
                }
                else
                {
                    lblFrom.Text = "From: " + prof + "   To: " + txtPersentage.Text;
                    pnlConfirm.Visible = true;
                }
            }
        }

        #region All other methods
        public void ValidateEmpty()
        {
            if (txtItemName.Text == "")
            {
                lblError.Text = "Please enter an Item Code";
                isEmpty = true;
            }
            else if (ddlCatagory.SelectedItem.ToString() == "-Select Catagory-")
            {
                lblError.Text = "Please enter Select a Catagory";
                isEmpty = true;
            }
            else if (txtQuantity.Text == "")
            {
                lblError.Text = "Please enter a Quantity";
                isEmpty = true;
            }
            else if (txtCost.Text == "")
            {
                lblError.Text = "Please enter a Cost per item";
                isEmpty = true;
            }
            else if (txtPersentage.Text == "")
            {
                try
                {
                    // Connecting to the database using the database connection string
                    MySqlConnection myConn = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.product;", myConn);
                    // Enableing the application to retreve data from the database
                    MySqlDataReader myReader;
                    // The connection is opened
                    myConn.Close();
                    myConn.Open();
                    myReader = SelectCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        txtPersentage.Text = myReader["itemProffitPercentage"].ToString();
                        ValidateEmpty();
                    }
                    myConn.Close();
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message.ToString() + ", please try again";
                    isEmpty = true;
                }
            }
            else if (txtArtistName.Text == "")
            {
                lblError.Text = "Please enter an Artist Name";
                isEmpty = true;
            }
            else if (txtAlbumName.Text == "")
            {
                lblError.Text = "Please enter an Album Name";
                isEmpty = true;
            }
            else if (txtReleaseDate.Text == "")
            {
                lblError.Text = "Please enter a Release Date";
                isEmpty = true;
            }
            else if (ddlGenre.SelectedItem.ToString() == "-Select Genre-")
            {
                lblError.Text = "Please enter Select a Genre";
                isEmpty = true;
            }
            else if (ddlBranch.SelectedItem.ToString() == "-Select Branch -")
            {
                lblError.Text = "Please enter Select a Genre";
                isEmpty = true;
            }
            else
            {
                isEmpty = false;
                txtCost.Text = toTwoDecimal(Convert.ToDecimal(txtCost.Text)).ToString();
            }
        }

        public decimal toTwoDecimal(decimal number)
        {
            string a = number.ToString();

            int length = a.Length;
            char ch = '.';
            int pos = 0;

            for (int c = 0; c < length; c++)
            {
                string nA = a[c].ToString();
                if (nA == ch.ToString())
                {
                    pos = c;
                    break;
                }
            }

            number = 0;
            string currency = "";
            for (int i = 0; i <= pos + 2; i++)
            {
                currency = currency + a[i].ToString();
            }

            number = Convert.ToDecimal(currency);
            return number;
        }

        public void ProductExist()
        {
            Product = false;
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.product WHERE productCode='" + txtItemName.Text + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Close();
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    Product = true;
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString() + ", please try again";
            }
        }

        public void StockExist()
        {
            Branch = false;
            ProductExist();
            GetBranchID();
            if (Product == true)
            {
                try
                {
                    // Connecting to the database using the database connection string
                    MySqlConnection myConn = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand SelectCommandBranch = new MySqlCommand("SELECT * FROM pavanicadatabase.branchproduct WHERE branchID='" + AddStockBranchID + "' AND productCode = '" + txtItemName.Text + "';", myConn);
                    // Enableing the application to retreve data from the database
                    MySqlDataReader myReader;
                    // The connection is opened
                    myConn.Close();
                    myConn.Open();
                    myReader = SelectCommandBranch.ExecuteReader();

                    while (myReader.Read())
                    {
                        Branch = true;
                    }
                    myConn.Close();
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message.ToString() + ", please try again";
                }
            }
        }

        public void UpdateItemAndBranch()
        {
            Quantity();
            Price();
            GetBranchID();

            smes = "Update Item";
            InventoryClass inv = new InventoryClass(txtItemName.Text, ddlCatagory.SelectedItem.ToString(), txtAlbumName.Text, txtArtistName.Text, txtReleaseDate.Text, iquantity, ddlGenre.SelectedItem.ToString(), dPrice, dCost, iproffits, AddStockBranchID, smes);
            smes = inv.Messages.ToString();
            if (smes == "Done")
            {
                lblError.Text = "The product was successfully Updated";
                ddlGenre.SelectedIndex = 0;
                ddlCatagory.SelectedIndex = 0;
                txtItemName.Text = "";
                txtPersentage.Text = "";
                txtCost.Text = "";
                txtArtistName.Text = "";
                txtAlbumName.Text = "";
                txtQuantity.Text = "";
                txtReleaseDate.Text = "";
            }
            else
            {
                lblError.Text = smes + ", please try again";
                ddlGenre.SelectedIndex = 0;
                ddlCatagory.SelectedIndex = 0;
                txtItemName.Text = "";
                txtPersentage.Text = "";
                txtCost.Text = "";
                txtArtistName.Text = "";
                txtAlbumName.Text = "";
                txtQuantity.Text = "";
                txtReleaseDate.Text = "";
            }
        }

        public void UpdateItemOnly()
        {
            Quantity();
            Price();
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConne = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand UpdateCommand = new MySqlCommand("UPDATE pavanicadatabase.product SET productType='" + ddlCatagory.SelectedItem.ToString() + "', productAlbum='" + txtAlbumName.Text + "', productArtist='" + txtArtistName.Text + "', productReleaseDate='" + txtReleaseDate.Text + "', itemGenre='" + ddlGenre.SelectedItem.ToString() + "', itemPrice='" + dPrice + "', itemCostValue='" + dCost + "', itemProffitPercentage='" + iproffits + "' WHERE productCode='" + txtItemName.Text + "';", myConne);
                // The connection is opened
                myConne.Close();
                myConne.Open();
                UpdateCommand.ExecuteNonQuery();
                myConne.Close();

                lblError.Text = "The product was successfully Updated";
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString() + ", please try again";
            }
        }

        public void UpdateBranch()
        {
            GetBranchID();
            try
            {
                Quantity();
                // Connecting to the database using the database connection string
                MySqlConnection myConne = new MySqlConnection(connection);
                //The Select statment for branch
                MySqlCommand UpdateCommandBranch = new MySqlCommand("UPDATE pavanicadatabase.branchproduct SET quantityAvailable='" + iquantity + "' WHERE branchID='" + AddStockBranchID + "' AND productCode = '" + txtItemName.Text + "';", myConne);
                // The connection is opened
                myConne.Close();
                myConne.Open();
                UpdateCommandBranch.ExecuteNonQuery();
                myConne.Close();

                lblError.Text = "The Quantity was successfully Updated";
                ddlGenre.SelectedIndex = 0;
                ddlCatagory.SelectedIndex = 0;
                txtItemName.Text = "";
                txtPersentage.Text = "";
                txtCost.Text = "";
                txtArtistName.Text = "";
                txtAlbumName.Text = "";
                txtQuantity.Text = "";
                txtReleaseDate.Text = "";
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString() + ", please try again";
                ddlGenre.SelectedIndex = 0;
                ddlCatagory.SelectedIndex = 0;
                txtItemName.Text = "";
                txtPersentage.Text = "";
                txtCost.Text = "";
                txtArtistName.Text = "";
                txtAlbumName.Text = "";
                txtQuantity.Text = "";
                txtReleaseDate.Text = "";
            }
        }

        public void Quantity()
        {
            try
            {
                iquantity = Int32.Parse(txtQuantity.Text);
            }
            catch (Exception)
            {
                lblError.Text = "The Quantity is invalid";
            }
        }

        public void Cost()
        {
            try
            {
                dCost = Convert.ToDecimal(txtCost.Text);
                dCost = toTwoDecimal(dCost);
            }
            catch (Exception)
            {
                lblError.Text = "The Cost is invalid";
            }
        }

        public void Price()
        {
            Cost();
            Proffit();
            dPrice = dCost + (dCost * (Convert.ToDecimal(iproffits) / 100));
            dPrice = (dPrice * Convert.ToDecimal("0.14")) + dPrice;
            dPrice = toTwoDecimal(dPrice);
        }

        public void Proffit()
        {
            try
            {
                iproffits = Int32.Parse(txtPersentage.Text);
            }
            catch (Exception)
            {
                lblError.Text = "The Cost is invalid";
            }
        }

        public void GetBranchID()
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommandBranch = new MySqlCommand("SELECT * FROM pavanicadatabase.branch WHERE branchName='" + ddlBranch.SelectedItem.ToString() + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Close();
                myConn.Open();
                myReader = SelectCommandBranch.ExecuteReader();

                while (myReader.Read())
                {
                    AddStockBranchID = myReader["branchID"].ToString();
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString() + ", please try again";
            }
        }

        public void GetProffit()
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.product;", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Close();
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    prof = myReader["itemProffitPercentage"].ToString();
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString() + ", please try again";
            }
        }
        #endregion

        protected void btnAddItem_Click(object sender, EventArgs e)
        {
            lblError.Text = "";
            ValidateEmpty();
            GetBranchID();
            if (isEmpty != true)
            {
                Quantity();
                Price();
                ProductExist();
                if (Product == true)
                {
                    StockExist();
                    if (Branch == true)
                    {
                        btnSave_Click(sender, e);
                        UpdateBranch();
                    }
                    else
                    {
                        #region Try to Add a new item
                        try
                        {
                            // Connecting to the database using the database connection string
                            MySqlConnection myConne = new MySqlConnection(connection);
                            // The Select statement
                            MySqlCommand InsertCommandBranch = new MySqlCommand("INSERT INTO pavanicadatabase.branchproduct(branchID,productCode,quantityAvailable) VALUES ('" + AddStockBranchID + "','" + txtItemName.Text + "','" + iquantity + "');", myConne);
                            MySqlCommand InsertCommandLocal = new MySqlCommand("INSERT INTO pavanicadatabase.localchart(branchID,productCode,Lsold) VALUES ('" + AddStockBranchID + "','" + txtItemName.Text + "','" + 0 + "');", myConne);
                            // The connection is opened
                            myConne.Close();
                            myConne.Open();
                            InsertCommandLocal.ExecuteNonQuery();
                            InsertCommandBranch.ExecuteNonQuery();
                            myConne.Close();

                            btnSave_Click(sender, e);
                            lblError.Text = "The product was successfully Added";
                            ddlGenre.SelectedIndex = 0;
                            ddlCatagory.SelectedIndex = 0;
                            txtItemName.Text = "";
                            txtPersentage.Text = "";
                            txtCost.Text = "";
                            txtArtistName.Text = "";
                            txtAlbumName.Text = "";
                            txtQuantity.Text = "";
                            txtReleaseDate.Text = "";
                        }
                        catch (Exception ex)
                        {
                            lblError.Text = ex + ", please try again";
                            ddlGenre.SelectedIndex = 0;
                            ddlCatagory.SelectedIndex = 0;
                            txtItemName.Text = "";
                            txtPersentage.Text = "";
                            txtCost.Text = "";
                            txtArtistName.Text = "";
                            txtAlbumName.Text = "";
                            txtQuantity.Text = "";
                            txtReleaseDate.Text = "";
                        }
                        #endregion
                    }
                }
                else
                {
                    lblError.Text = "";
                    smes = "Add Item";
                    InventoryClass inv = new InventoryClass(txtItemName.Text, ddlCatagory.SelectedItem.ToString(), txtAlbumName.Text, txtArtistName.Text, txtReleaseDate.Text, iquantity, ddlGenre.SelectedItem.ToString(), dPrice, dCost, iproffits, AddStockBranchID, smes);
                    smes = inv.Messages.ToString();
                    if (smes == "Done")
                    {
                        btnSave_Click(sender, e);
                        lblError.Text = "The product was successfully Added";
                        ddlGenre.SelectedIndex = 0;
                        ddlCatagory.SelectedIndex = 0;
                        txtItemName.Text = "";
                        txtPersentage.Text = "";
                        txtCost.Text = "";
                        txtArtistName.Text = "";
                        txtAlbumName.Text = "";
                        txtQuantity.Text = "";
                        txtReleaseDate.Text = "";

                    }
                    else
                    {
                        lblError.Text = smes + ", please try again";
                        ddlGenre.SelectedIndex = 0;
                        ddlCatagory.SelectedIndex = 0;
                        txtItemName.Text = "";
                        txtPersentage.Text = "";
                        txtCost.Text = "";
                        txtArtistName.Text = "";
                        txtAlbumName.Text = "";
                        txtQuantity.Text = "";
                        txtReleaseDate.Text = "";
                    }
                }
            }
        }

        protected void btnRemoveItem_Click(object sender, EventArgs e)
        {
            ProductExist();
            if (Product == true)
            {
                lblError.Text = "";
                smes = "Delete Item";
                InventoryClass inv = new InventoryClass(txtItemName.Text, ddlCatagory.SelectedItem.ToString(), txtAlbumName.Text, txtArtistName.Text, txtReleaseDate.Text, iquantity, ddlGenre.SelectedItem.ToString(), dPrice, dCost, iproffits, AddStockBranchID, smes);
                smes = inv.Messages.ToString();
                if (smes == "Done")
                {
                    lblError.Text = "The product was successfully Removed";
                    ddlGenre.SelectedIndex = 0;
                    ddlCatagory.SelectedIndex = 0;
                    txtItemName.Text = "";
                    txtPersentage.Text = "";
                    txtCost.Text = "";
                    txtArtistName.Text = "";
                    txtAlbumName.Text = "";
                    txtQuantity.Text = "";
                    txtReleaseDate.Text = "";
                }
                else
                {
                    lblError.Text = smes + ", please try again";
                    ddlGenre.SelectedIndex = 0;
                    ddlCatagory.SelectedIndex = 0;
                    txtItemName.Text = "";
                    txtPersentage.Text = "";
                    txtCost.Text = "";
                    txtArtistName.Text = "";
                    txtAlbumName.Text = "";
                    txtQuantity.Text = "";
                    txtReleaseDate.Text = "";
                }
            }
            else
            {
                lblError.Text = "The Item does not Exist";
                ddlGenre.SelectedIndex = 0;
                ddlCatagory.SelectedIndex = 0;
                txtItemName.Text = "";
                txtPersentage.Text = "";
                txtCost.Text = "";
                txtArtistName.Text = "";
                txtAlbumName.Text = "";
                txtQuantity.Text = "";
                txtReleaseDate.Text = "";
            }
        }

        protected void btnYes_Click(object sender, EventArgs e)
        {
            try
            {
                #region Try to get proffit percentage
                try
                {
                    // Connecting to the database using the database connection string
                    MySqlConnection myConn = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.product;", myConn);
                    // Enableing the application to retreve data from the database
                    MySqlDataReader myReader;
                    // The connection is opened
                    myConn.Close();
                    myConn.Open();
                    myReader = SelectCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        #region try to update the proffit percentage
                        try
                        {
                            Price();
                            // Connecting to the database using the database connection string
                            MySqlConnection myConne = new MySqlConnection(connection);
                            // The Select statement
                            MySqlCommand UpdateCommand = new MySqlCommand("UPDATE pavanicadatabase.product SET itemProffitPercentage='" + iproffits + "';", myConne);
                            // The connection is opened
                            myConne.Close();
                            myConne.Open();
                            UpdateCommand.ExecuteNonQuery();
                            myConne.Close();
                            txtPersentage.Text = iproffits.ToString();
                        }
                        catch (Exception ex)
                        {
                            lblError.Text = ex.Message.ToString() + ", please try again";
                        }
                        #endregion
                    }
                    myConn.Close();
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message.ToString() + ", please try again";
                }
                #endregion
            }
            catch (Exception)
            {
                lblError.Text = "The Proffit Percentage is invalid";
            }
            pnlConfirm.Visible = false;
        }

        protected void btnNo_Click(object sender, EventArgs e)
        {
            GetProffit();
            txtPersentage.Text = prof;
            pnlConfirm.Visible = false;
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            ValidateEmpty();
            StockExist();
            if (Product == true)
            {
                UpdateItemOnly();
                ddlGenre.SelectedIndex = 0;
                ddlCatagory.SelectedIndex = 0;
                txtItemName.Text = "";
                txtPersentage.Text = "";
                txtCost.Text = "";
                txtArtistName.Text = "";
                txtAlbumName.Text = "";
                txtQuantity.Text = "";
                txtReleaseDate.Text = "";
            }
            else
            {
                lblError.Text = "The Item does not Exist";
                ddlGenre.SelectedIndex = 0;
                ddlCatagory.SelectedIndex = 0;
                txtItemName.Text = "";
                txtPersentage.Text = "";
                txtCost.Text = "";
                txtArtistName.Text = "";
                txtAlbumName.Text = "";
                txtQuantity.Text = "";
                txtReleaseDate.Text = "";
            }
        }

        protected void btnClear_Click(object sender, ImageClickEventArgs e)
        {
            ddlGenre.SelectedIndex = 0;
            ddlCatagory.SelectedIndex = 0;
            txtItemName.Text = "";
            txtPersentage.Text = "";
            txtCost.Text = "";
            txtArtistName.Text = "";
            txtAlbumName.Text = "";
            txtQuantity.Text = "";
            txtReleaseDate.Text = "";
        }
    }
}
        















        