﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class WebForm11 : System.Web.UI.Page
    {
        // database connection
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        // Global variables
        #region Values Passed through the system
        string sBranchName;
        string sBranchID;
        string sUsername;
        string sPassword;
        string accesstype;
        string button;
        #endregion

        string message = "";

        #region Values that stay here 
        string Cellno = "";
        string Name = "";
        string Surname = "";
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                sUsername = Session["username"].ToString();
                sPassword = Session["password"].ToString();

                 // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.employees WHERE empID='" + sUsername + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Close();
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    #region Load values into textboxes

                    Cellno = txtCell.Text;
                    Name = txtName.Text;
                    Surname = txtSurname.Text;
                    if (Cellno != "")
                    {
                        txtCell.Text = Cellno;
                    }
                    else
                    {
                        txtCell.Text = myReader["empCell"].ToString();
                        Cellno = txtCell.Text;
                        txtCell_TextChanged(sender, e);
                    }

                    if (Name != "")
                    {
                        txtName.Text = Name;
                    }
                    else
                    {
                        txtName.Text = myReader["empName"].ToString();
                    }

                    if (Surname != "")
                    {
                        txtSurname.Text = Surname;
                    }
                    else
                    {
                        txtSurname.Text = myReader["empSurname"].ToString();
                    }
                    #endregion

                    sBranchName = Session["branchName"].ToString();
                    sBranchID = Session["branchID"].ToString();
                    button = Session["button"].ToString();
                    txtUsername.Text = sUsername;
                    accesstype = Session["Access"].ToString();
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString();
                txtUsername.Text = "";
                txtCell.Text = "";
                txtName.Text = "";
                txtSurname.Text = "";
                txtPassword.Text = "";
                txtPasswordCon.Text = "";
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            // Validate txtCell
            txtCell_TextChanged(sender, e);
            #region Check empty fields
            if (txtName.Text == "")
            {
                lblError.Text = "Please enter your Name";
            }
            else if (txtSurname.Text == "")
            {
                lblError.Text = "Please enter your Surname";
            }
            else if (txtCell.Text == "")
            {
                lblError.Text = "Please enter your Cell phone number";
            }
            else if (txtOldPassword.Text == "")
            {
                lblError.Text = "Please enter your Old Password";
            }
            else if (txtOldPassword.Text != sPassword)
            {
                lblError.Text = "Your Old Password is incorrect";
            }
            else if (txtPassword.Text == "")
            {
                lblError.Text = "Please enter your New Password";
            }
            else if (txtPasswordCon.Text == "")
            {
                lblError.Text = "Please Confirm your Password";
            }
            else if (txtPasswordCon.Text != txtPassword.Text)
            {
                lblError.Text = "Passwords does not match";
            }
            #endregion
            else
            {
                message = "Update Employee";
                EmployeeClass emp = new EmployeeClass(message, txtUsername.Text, sBranchID, accesstype, txtName.Text, txtSurname.Text, txtCell.Text, txtOldPassword.Text, txtPassword.Text, txtPasswordCon.Text);
                message = emp.Messages.ToString();
                if (message == "Error: User does exist")
                {
                    lblError.Text = message + ", please try again";
                    Page_Load(sender, e);
                }
                else if (message == "Done")
                {
                    lblError.Text = "Updating information was sucsessful";
                    Page_Load(sender, e);
                }
                else
                {
                    lblError.Text = message + ", please try again";
                    Page_Load(sender, e);
                }
            }
        }

        protected void txtCell_TextChanged(object sender, EventArgs e)
        {
            int Length = 0;
            string temporary = Cellno;
            Length = temporary.Length;

            #region Length = 10
            if (Length == 10)
            {
                lblError.Text = "";
                for (int a = 0; a < Length; a++)
                {
                    string s = temporary[a].ToString();
                    switch (s)
                    {
                        case "0":
                            if (temporary[0].ToString() != "0")
                            {
                                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            }
                            break;
                        case "1":
                            if (temporary[0].ToString() != "0")
                            {
                                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            }
                            break;
                        case "2":
                            if (temporary[0].ToString() != "0")
                            {
                                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            }
                            break;
                        case "3":
                            if (temporary[0].ToString() != "0")
                            {
                                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            }
                            break;
                        case "4":
                            if (temporary[0].ToString() != "0")
                            {
                                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            }
                            break;
                        case "5":
                            if (temporary[0].ToString() != "0")
                            {
                                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            }
                            break;
                        case "6":
                            if (temporary[0].ToString() != "0")
                            {
                                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            }
                            break;
                        case "7":
                            if (temporary[0].ToString() != "0")
                            {
                                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            }
                            break;
                        case "8":
                            if (temporary[0].ToString() != "0")
                            {
                                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            }
                            break;
                        case "9":
                            if (temporary[0].ToString() != "0")
                            {
                                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            }
                            break;
                        default:
                            lblError.Text = "The cell phone number is invalide, eg: 0689585841";
                            break;
                    }
                }
            }
            #endregion
            else
            {
                lblError.Text = "The cell phone number is invalide, eg: 0689585841";
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            if (accesstype == "Sales Clerk")
            {
                try
                {
                    //try to redirect to the selection page
                    Session["branchName"] = sBranchName;
                    Session["branchID"] = sBranchID;
                    Session["password"] = sPassword;
                    Session["username"] = sUsername;
                    Session["access"] = accesstype;
                    Session["button"] = button;
                    Server.Transfer("~/Selection.aspx");
                    Response.Redirect("Selection.aspx");
                }
                catch (Exception ex)
                {
                    Response.Redirect("Selection.aspx");
                }
            }
            else
            {
                try
                {
                    //try to redirect to the employee info page
                    Session["branchName"] = sBranchName;
                    Session["branchID"] = sBranchID;
                    Session["password"] = sPassword;
                    Session["username"] = sUsername;
                    Session["access"] = accesstype;
                    Session["button"] = button;
                    Server.Transfer("~/EmployeeInfo.aspx");
                    Response.Redirect("EmployeeInfo.aspx");
                }
                catch (Exception ex)
                {
                    Response.Redirect("EmployeeInfo.aspx");
                }
            }
            
        }
    }
}