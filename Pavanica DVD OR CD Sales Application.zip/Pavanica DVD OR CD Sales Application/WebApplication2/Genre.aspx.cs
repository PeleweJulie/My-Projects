﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class Local : System.Web.UI.Page
    {
        string sGenre = "";
        string sBranch = "";
        string sButton = "";
        string Tbutton = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                Tbutton = Session["Top10"].ToString();
                sBranch = Session["branch"].ToString();
                sButton = Session["button"].ToString();
            }
            catch (Exception ex)
            {
                //ignore error
            }
        }

        protected void btnBack_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                if (sButton == "Local Charts")
                {
                    //try to redirect to the Charts page
                Response.Redirect("Charts.aspx");
                }
                //try to redirect to the home page
                Response.Redirect("Home.aspx");
            }
            catch (Exception ex)
            {
                //do nothing
            }
        }

        protected void btnNext_Click(object sender, ImageClickEventArgs e)
        {
            if (rblGenre.SelectedIndex == -1)
            {
                lblError.Text = "Please select a Genre";
            }
            else
            {
                try
                {
                    // try to redirect to the top 10 page
                    sGenre = rblGenre.SelectedItem.ToString();
                    if (Tbutton == "Top10Button")
                    {
                        Session["branch"] = "National";
                        Session["button"] = "National Charts";
                    }
                    else
                    {
                        Session["branch"] = sBranch;
                        Session["button"] = sButton;
                    }
                    Session["genre"] = sGenre;
                    Server.Transfer("~/Top10.aspx");
                    Response.Redirect("Top10.aspx");
                }
                catch (Exception ex)
                {
                    //ignore error
                }
            }
        }
    }
}