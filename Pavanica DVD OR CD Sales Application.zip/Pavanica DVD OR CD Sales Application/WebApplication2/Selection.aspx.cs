﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        string sBranchName;
        string sBranchID;
        string sUsername;
        string sPassword;
        string accesstype;
        string button;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                #region Get information
                sBranchName = Session["branchName"].ToString();
                sBranchID = Session["branchID"].ToString();
                sPassword = Session["password"].ToString();
                sUsername = Session["username"].ToString();
                accesstype = Session["access"].ToString();
                button = Session["button"].ToString();
                bool stock = false;
                lblBranchName.Text = "You are logged in at the " + sBranchName + " branch.   Please select an action.";
                #endregion

                if (accesstype == "Administrator")
                {
                    btnBack.Visible = true;
                }
                else
                {
                    btnBack.Visible = false;
                }

                #region if branch has stock
                try
                {   
                    // Connecting to the database using the database connection string
                    MySqlConnection myConn = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.branchproduct WHERE branchID='" + sBranchID + "';", myConn);
                    // Enableing the application to retreve data from the database
                    MySqlDataReader myReader;
                    // The connection is opened
                    myConn.Close();
                    myConn.Open();
                    myReader = SelectCommand.ExecuteReader();

                    while (myReader.Read())
                    {
                        stock = true;
                        if (button == "Sales Clerk")
                        {
                            btnStock.Enabled = false;
                            btnSalesReport.Enabled = false;
                            btnSalesRegistry.Enabled = true;
                            btnSearchItem.Enabled = true;
                        }
                        else
                        {
                            btnStock.Enabled = true;
                            btnSalesReport.Enabled = true;
                            btnSalesRegistry.Enabled = true;
                            btnSearchItem.Enabled = true;
                        }
                    }
                    myConn.Close();
                }
                catch (Exception ex)
                {
                    // Ignore errors
                }
                #endregion

                #region if branch don't have stock
                if ((button == "Sales Clerk") && (stock == false))
                {
                    btnStock.Enabled = false;
                    btnSalesReport.Enabled = false;
                    btnSalesRegistry.Enabled = false;
                    btnSearchItem.Enabled = false;
                    lblError.Text = "Please add some stock";
                }
                else if (((button == "Manager") && (stock == false)) || (button == "Administrator") && (stock == false))
                {
                    btnStock.Enabled = true;
                    btnSalesReport.Enabled = false;
                    btnSalesRegistry.Enabled = false;
                    btnSearchItem.Enabled = false;
                    lblError.Text = "Please add some stock";
                }
                #endregion
            }
            catch (Exception)
            {
                // Ignore error
            }
        }

        protected void btnSalesRegistry_Click(object sender, EventArgs e)
        {
            try
            {
                //try to redirect to the sales page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Sales.aspx");
                Response.Redirect("Sales.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Sales.aspx");
            }
        }

        protected void btnSearchItem_Click(object sender, EventArgs e)
        {
            try
            {
                //try to redirect to the search page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Search.aspx");
                Response.Redirect("Search.aspx");
            }
            catch
            {
                Response.Redirect("Search.aspx");
            }
        }

        protected void btnStock_Click(object sender, EventArgs e)
        {
            try
            {
                //try to redirect to the stock control page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Stock.aspx");
                Response.Redirect("Stock.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Stock.aspx");
            }
        }

        protected void btnSalesReport_Click(object sender, EventArgs e)
        {
            try
            {
                //try to redirect to the reports page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Reports.aspx");
                Response.Redirect("Reports.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Reports.aspx");
            }
        }

        protected void btnEmployeeInfo_Click(object sender, EventArgs e)
        {
            try
            {
                //try to redirect to the employee info page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/EmployeeInfo.aspx");
                Response.Redirect("EmployeeInfo.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("EmployeeInfo.aspx");
            }
        }

        protected void btnBack_Click1(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the Branch page
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Branch.aspx");
                Response.Redirect("Branch.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Branch.aspx");
            }
        }

        protected void ibtnLogout_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the home page
                Response.Redirect("Home.aspx");
            }
            catch
            {
                //do nothing
            }
        }

        protected void btnHelp_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the employee info page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Help.aspx");
                Response.Redirect("Help.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Help.aspx");
            }
        }
    }
}