﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        public string sButton;
        public string sBranch;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                sButton = Session["Top10"].ToString();
            }
            catch (Exception ex)
            {
                //ignore error
            }
        }

        protected void btnNational_Click(object sender, ImageClickEventArgs e)
        {
            National();
        }

        protected void btnLocal_Click(object sender, ImageClickEventArgs e)
        {
            ddlBranch.Visible = true;
        }

        protected void btnBack_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to Home page
                Response.Redirect("Home.aspx");
            }
            catch (Exception ex)
            {
                //do nothing
            }
        }

        protected void ddlBranch_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlBranch.SelectedItem.ToString() != "-Select Branch-")
            {
                sBranch = ddlBranch.SelectedItem.ToString();
                Local();
            }
        }

        public void National()
        {
            try
            {
                // try to redirect to National top 10
                Session["branch"] = "National";
                Session["button"] = "National Charts";
                Session["Top10"] = "Top10Button";
                Server.Transfer("~/Genre.aspx");
                Response.Redirect("Genre.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Genre.aspx");
            }
        }

        public void Local()
        {
            try
            {
                // try to redirect to Local top 10
                Session["branch"] = sBranch.ToString();
                Session["button"] = "Local Charts";
                Session["Top10"] = sButton;
                Server.Transfer("~/Genre.aspx");
                Response.Redirect("Genre.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Genre.aspx");
            }
        }
    }
}