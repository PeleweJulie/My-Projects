﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        string sBranchName, branch, productCodeName;
        string sBranchID, SelectedBranchID, empBranch;
        string sUsername, SelectedBranchName, SempID;
        string sPassword, saleDateTime;
        string accesstype, SaleID;
        string button;

        decimal TotalProffit = 0;
        decimal TotalVAT = 0;
        decimal Total = 0;
        decimal SaleTotal = 0, Proffit = 0, VAT = 0;
        decimal ppUinit = 0, CostValue = 0;
        int quantity = 0;
        
        bool errorState = false;


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                sBranchName = Session["branchName"].ToString();
                sBranchID = Session["branchID"].ToString();
                sPassword = Session["password"].ToString();
                sUsername = Session["username"].ToString();
                accesstype = Session["access"].ToString();
                button = Session["button"].ToString();

                try
                {
                    Session["Branch"] = ddlBranch.SelectedItem.ToString();
                    branch = Session["Branch"].ToString();
                }
                catch (Exception)
                {
                    // Ignore error
                }

                if (accesstype != "Administrator")
                {
                    ddlBranch.Enabled = false;
                    ddlBranch.ClearSelection();
                    ddlBranch.Items.FindByValue(sBranchName).Selected = true;
                }
                else
                {
                    ddlBranch.Enabled = true;
                }
                
            }
            catch (Exception)
            {
                // Ignore error
            }
        }

        protected void btnGenerate_Click(object sender, EventArgs e)
        {
            #region Setting up defults
            txtReport.Text = "";
            Total = 0;
            TotalProffit = 0;
            TotalVAT = 0;
            SaleTotal = 0;
            Proffit = 0;
            VAT = 0;
            lblError.Text = "";
            errorState = false;
            #endregion

            if (branch == "-Select Branch -")
            {
                lblError.Text = "Please Select a Branch";
            }
            else if (calStart.SelectedDate.ToShortDateString() == "1/1/0001")
            {
                lblError.Text = "Please Select a Starting date for the Report";
            }
            else if (calEnd.SelectedDate.ToShortDateString() == "1/1/0001")
            {
                lblError.Text = "Please Select an Ending date for the Report";
            }
            else
            {
                #region check if start is after end
                if (calStart.SelectedDate <= calEnd.SelectedDate)
                {
                    Sale();
                    if (errorState != true)
                    {
                        PrintHeadder(ddlBranch.SelectedItem.ToString());
                        PrintFooter();
                    }
                    else
                    {
                        txtReport.Text = "";
                    } 
                }
                else
                {
                    lblError.Text = "The Ending Date cannot be before the Starting Date of the Report";
                }
                #endregion
            }            
        }

        public void PrintHeadder(string Branch)
        {
            if (Branch == "All Branches")
            {
                txtReport.Text = "Sales Report \nReport period from: " + calStart.SelectedDate.ToShortDateString() + " to: " + calEnd.SelectedDate.ToShortDateString() + "\n\n\n" + txtReport.Text;
            }
            else
            {
                txtReport.Text = "Sales Report \nReport period from: " + calStart.SelectedDate.ToShortDateString() + " to: " + calEnd.SelectedDate.ToShortDateString() + "\nBranch Code: " + SelectedBranchID + " Branch Name: " + SelectedBranchName + "\n\n\n" + txtReport.Text;
            }
        }

        public void PrintFooter()
        {
            txtReport.Text = txtReport.Text + "\n\nTOTAL Income for selected period:  R " + Total.ToString();
            txtReport.Text = txtReport.Text + "\nTOTAL VAT for selected period:     R " + TotalVAT.ToString();
            txtReport.Text = txtReport.Text + "\nTOTAL Profit for selected period: R " + TotalProffit.ToString();
        }

        public void PrintBody()
        {
            if (ddlBranch.SelectedItem.ToString() == "All Branches")
            {
                txtReport.Text = txtReport.Text + "** Date and Time: " + saleDateTime + "   Sale No. " + SaleID + "    Branch Name: " + SelectedBranchName + "    Product Code and Name: " + productCodeName + "    Price per Unit: R " + ppUinit + "    Quantity Sold: " + quantity + "   Total: R " + SaleTotal + "\n\n";
            }
            else
            {
                txtReport.Text = txtReport.Text + "** Date and Time: " + saleDateTime + "   Sale No. " + SaleID + "    Product Code and Name: " + productCodeName + "    Price per Unit: R " + ppUinit + "    Quantity Sold: " + quantity + "   Total: R " + SaleTotal + "\n\n";
            }

            //Calculate Totals
            calcTotal();
            calcTotalProffit();
            calcTotalVAT();
        }

        // converting the date onto the following format: yyyy-mm-dd;
        public string convertDate(string date)
        {
            string Day;
            string Month;
            string Year;
            string totalDate;
            string value;
            int length;

            totalDate = date;
            length = totalDate.Length;
            for (int n = 0; n < length; n++)
            {
                value = date[n].ToString();
                if (value == "/")
                {
                    if (n == 1)
                    {
                        totalDate = "0" + totalDate;
                    }
                    else if (n == 2)
                    {
                        totalDate = totalDate.Insert(n+1, "0");
                    }
                }
            }

            Month = totalDate[0].ToString() + totalDate[1].ToString();
            Day = totalDate[3].ToString() + totalDate[4].ToString();
            Year = totalDate[6].ToString() + totalDate[7].ToString() + totalDate[8].ToString() + totalDate[9].ToString();

            date = Year + "-" + Month + "-" + Day;
            return date;
        }

        public void Product(string productCode)
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConne = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectP = new MySqlCommand("SELECT * FROM pavanicadatabase.product WHERE productCode='" + productCode + "';", myConne);
                // Enableing the application to retreve data from the database
                MySqlDataReader Reader;
                // The connection is opened
                myConne.Open();
                Reader = SelectP.ExecuteReader();

                while (Reader.Read())
                {
                    productCodeName= productCode + " " + Reader["ProductAlbum"].ToString();
                    CostValue = decimal.Parse(Reader["itemCostValue"].ToString());

                    decimal Uinit = CostValue + (CostValue * (Convert.ToDecimal(Reader["itemProffitPercentage"].ToString()) / 100));
                    ppUinit = Uinit + (Uinit * Convert.ToDecimal("0.14"));

                    ppUinit = toTwoDecimal(ppUinit);
                    CostValue = toTwoDecimal(CostValue);
                }
                myConne.Close();
            }
            catch (Exception ex)
            {
                errorState = true;
                lblError.Text = "Error! " + ex.Message.ToString() + ", Please try again later";
            }

        }

        public void ProductBranch(string BranchID, string code)
        {
            string branchName;
            branchName = ddlBranch.SelectedItem.ToString();

            if ((branchName == "All Branches") && (accesstype == "Administrator"))
            {
                try
                {
                    // Connecting to the database using the database connection string
                    MySqlConnection myConne = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand Select = new MySqlCommand("SELECT * FROM pavanicadatabase.Branch WHERE branchID='" + BranchID + "';", myConne);
                    // Enableing the application to retreve data from the database
                    MySqlDataReader Reader;
                    // The connection is opened
                    myConne.Open();
                    Reader = Select.ExecuteReader();

                    while (Reader.Read())
                    {
                        SelectedBranchName = Reader["branchName"].ToString();
                        SelectedBranchID = Reader["branchID"].ToString();
                        Product(code);
                        PrintBody();
                    }
                    myConne.Close();
                }
                catch (Exception ex)
                {
                    errorState = true;
                    lblError.Text = "Error! " + ex.Message.ToString() + ", Please try again later";
                }

            }
            else
            {
                try
                {
                    // Connecting to the database using the database connection string
                    MySqlConnection myConne = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand Select = new MySqlCommand("SELECT * FROM pavanicadatabase.Branch WHERE branchName='" + branchName + "';", myConne);
                    // Enableing the application to retreve data from the database
                    MySqlDataReader Reader;
                    // The connection is opened
                    myConne.Open();
                    Reader = Select.ExecuteReader();

                    while (Reader.Read())
                    {
                        SelectedBranchName = branchName;
                        SelectedBranchID = Reader["branchID"].ToString();

                        if (SelectedBranchID == BranchID)
                        {
                            Product(code);
                            PrintBody();
                        }
                    }
                    myConne.Close();
                }
                catch (Exception ex)
                {
                    errorState = true;
                    lblError.Text = "Error! " + ex.Message.ToString() + ", Please try again later 1";
                }
            }
        }

        public void Sale()
        {
            try
            {
                string start = convertDate(calStart.SelectedDate.ToShortDateString());
                string end = convertDate(calEnd.SelectedDate.ToShortDateString());

                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectCommand = new MySqlCommand("SELECT * FROM pavanicadatabase.Sales WHERE saleDate>='" + start  + " AND <=" + end + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader myReader;
                // The connection is opened
                myConn.Open();
                myReader = SelectCommand.ExecuteReader();

                while (myReader.Read())
                {
                    //Get Sale information
                    saleDateTime = convertDate(myReader["saleDate"].ToString()) +" " + myReader["saleTime"].ToString();
                    quantity = Int32.Parse(myReader["quantitySold"].ToString());
                    SaleTotal = decimal.Parse(myReader["saleTotal"].ToString());
                    Proffit = decimal.Parse(myReader["totalProffit"].ToString());
                    VAT = decimal.Parse(myReader["totalVAT"].ToString());

                    SaleTotal = toTwoDecimal(SaleTotal);
                    Proffit = toTwoDecimal(Proffit);
                    VAT = toTwoDecimal(VAT);

                    SaleID = myReader["salesID"].ToString();

                    //Get product information
                    ProductBranch(myReader["branchID"].ToString(), myReader["productCode"].ToString());
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                errorState = true;
                lblError.Text = "Error! " + ex.Message.ToString() + ", Please try again later 2";
            }
        }

        public void calcTotal()
        {
            Total = Total + SaleTotal;
            Total = toTwoDecimal(Total);
        }

        public void calcTotalProffit()
        {
            TotalProffit = TotalProffit + Proffit;
            TotalProffit = toTwoDecimal(TotalProffit);
        }

        public void calcTotalVAT()
        {
            TotalVAT = TotalVAT + VAT;
            TotalVAT = toTwoDecimal(TotalVAT);
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtReport.Text = "";
            ddlBranch.SelectedIndex = 0;
            calStart.SelectedDate = Convert.ToDateTime("01-01-0001");
            calEnd.SelectedDate = Convert.ToDateTime("01-01-0001");
        }

        public decimal toTwoDecimal(decimal number)
        {
            string a = number.ToString();

            int length = a.Length;
            char ch = '.';
            int pos = 0;

            for (int c = 0; c < length; c++)
            {
                string nA = a[c].ToString();
                if (nA == ch.ToString())
                {
                    pos = c;
                    break;
                }
            }

            number = 0;
            string currency = "";
            for (int i = 0; i <= pos + 2; i++)
            {
                currency = currency + a[i].ToString();
            }

            number = Convert.ToDecimal(currency);
            return number;
        }

        protected void btnBack_Click1(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the selection page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Selection.aspx");
                Response.Redirect("Selection.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Selection.aspx");
            }
        }
    }
}