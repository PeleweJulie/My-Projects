CREATE DATABASE  IF NOT EXISTS `pavanicadatabase` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `pavanicadatabase`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: 127.0.0.1    Database: pavanicadatabase
-- ------------------------------------------------------
-- Server version	5.6.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branch` (
  `branchID` varchar(10) NOT NULL,
  `branchName` varchar(45) NOT NULL,
  PRIMARY KEY (`branchID`),
  UNIQUE KEY `branchID_UNIQUE` (`branchID`),
  UNIQUE KEY `branchName_UNIQUE` (`branchName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES ('BLM003','Bloemfontein'),('CTN002','Cape Town'),('DBN001','Durban'),('JHB009','Johannesburg'),('KIM004','Kimberly'),('NEL005','Nelspruit'),('PEH006','Port Elizabeth'),('POT008','Potchefstroom'),('PTA010','Pretoria'),('WIT007','Witbank');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branchproduct`
--

DROP TABLE IF EXISTS `branchproduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branchproduct` (
  `branchID` varchar(10) NOT NULL,
  `productCode` varchar(45) NOT NULL,
  `quantityAvailable` int(11) NOT NULL,
  PRIMARY KEY (`branchID`,`productCode`),
  KEY `product_idx` (`productCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branchproduct`
--

LOCK TABLES `branchproduct` WRITE;
/*!40000 ALTER TABLE `branchproduct` DISABLE KEYS */;
INSERT INTO `branchproduct` VALUES ('BLM003','2558',20),('BLM003','6 002140 930425',13),('CTN002','6 002140 930425',16),('JHB009','6 002140 930425',20);
/*!40000 ALTER TABLE `branchproduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `empID` varchar(10) NOT NULL,
  `branchID` varchar(10) NOT NULL,
  `empStartDate` date NOT NULL,
  `empAccessType` varchar(45) NOT NULL,
  `empName` varchar(45) NOT NULL,
  `empSurname` varchar(45) NOT NULL,
  `empCell` varchar(12) NOT NULL,
  `empPassword` varchar(45) NOT NULL,
  PRIMARY KEY (`empID`,`branchID`),
  UNIQUE KEY `empID_UNIQUE` (`empID`),
  UNIQUE KEY `empCell_UNIQUE` (`empCell`),
  KEY `branchID_idx` (`branchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
INSERT INTO `employees` VALUES ('ADT258','PTA010','2014-02-03','Administrator','Arno','du Toit','0742182261','Arno1992');
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `localchart`
--

DROP TABLE IF EXISTS `localchart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `localchart` (
  `branchID` varchar(10) NOT NULL,
  `productCode` varchar(45) NOT NULL,
  `Lsold` int(11) NOT NULL,
  PRIMARY KEY (`branchID`,`productCode`),
  KEY `productCode_idx` (`productCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `localchart`
--

LOCK TABLES `localchart` WRITE;
/*!40000 ALTER TABLE `localchart` DISABLE KEYS */;
INSERT INTO `localchart` VALUES ('BLM003','2558',0),('BLM003','6 002140 930425',7),('CTN002','6 002140 930425',4),('JHB009','6 002140 930425',0);
/*!40000 ALTER TABLE `localchart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nationalchart`
--

DROP TABLE IF EXISTS `nationalchart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nationalchart` (
  `productCode` varchar(45) NOT NULL,
  `Nsold` int(11) NOT NULL,
  PRIMARY KEY (`productCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nationalchart`
--

LOCK TABLES `nationalchart` WRITE;
/*!40000 ALTER TABLE `nationalchart` DISABLE KEYS */;
INSERT INTO `nationalchart` VALUES ('2558',0),('6 002140 930425',11);
/*!40000 ALTER TABLE `nationalchart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `productCode` varchar(45) NOT NULL,
  `productType` varchar(4) NOT NULL,
  `productAlbum` varchar(45) NOT NULL,
  `productArtist` varchar(50) NOT NULL,
  `productReleaseDate` date NOT NULL,
  `itemGenre` varchar(45) NOT NULL,
  `itemPrice` decimal(45,2) NOT NULL,
  `itemCostValue` decimal(45,2) NOT NULL,
  `itemProffitPercentage` int(3) NOT NULL,
  PRIMARY KEY (`productCode`),
  UNIQUE KEY `productCode_UNIQUE` (`productCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES ('2558','CD','All the Right Reasons','Nickelback','2005-01-01','Other',154.56,58.95,130),('6 002140 930425','CD','The Dance','Dave Koz','1992-09-28','Other',152.04,57.99,130);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales`
--

DROP TABLE IF EXISTS `sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales` (
  `salesID` varchar(10) NOT NULL,
  `BranchID` varchar(10) NOT NULL,
  `productCode` varchar(45) NOT NULL,
  `saleDate` date NOT NULL,
  `saleTime` time NOT NULL,
  `quantitySold` int(11) NOT NULL,
  `saleTotal` decimal(45,2) NOT NULL,
  `totalVAT` decimal(45,2) NOT NULL,
  `totalProffit` decimal(45,2) NOT NULL,
  PRIMARY KEY (`salesID`),
  UNIQUE KEY `salesID_UNIQUE` (`salesID`),
  KEY `productCode_idx` (`productCode`),
  KEY `branchID_idx` (`BranchID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales`
--

LOCK TABLES `sales` WRITE;
/*!40000 ALTER TABLE `sales` DISABLE KEYS */;
INSERT INTO `sales` VALUES ('0','BLM003','6 002140 930425','2014-07-11','18:29:48',2,304.08,37.34,150.76),('1','BLM003','6 002140 930425','2014-07-11','18:34:50',1,152.04,18.67,75.38),('2','CTN002','6 002140 930425','2014-07-11','18:36:39',4,608.16,74.68,301.52),('3','BLM003','6 002140 930425','2014-07-13','18:24:56',2,304.08,37.34,150.76),('4','BLM003','6 002140 930425','2014-07-13','18:25:28',2,304.08,37.34,150.76);
/*!40000 ALTER TABLE `sales` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-07-21  9:17:20
