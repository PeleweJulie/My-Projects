﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class WebForm12 : System.Web.UI.Page
    {
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        string sBranchName;
        string sBranchID;
        string sUsername;
        string sPassword;
        string accesstype;
        string button;

        string pCode;
        string album;
        string artist;
        string rdate;
        string branchName, branchCode;
        string quantity;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                sBranchName = Session["branchName"].ToString();
                sBranchID = Session["branchID"].ToString();
                sPassword = Session["password"].ToString();
                sUsername = Session["username"].ToString();
                accesstype = Session["access"].ToString();
                button = Session["button"].ToString();
            }
            catch (Exception)
            {
                // Ignore error
            }
        }

        protected void btnSearch_Click(object sender, ImageClickEventArgs e)
        {
            txtResult.Text = "";
            if (txtSItemName.Text == "" && txtSArtistName.Text == "" && txtSAlbumName.Text == "" && txtSReleaseDate.Text == "")
            {
                lblError.Text = "Error! Invalide search. Please try again";
            }
            else
            {
                getProcut(txtSItemName.Text, txtSAlbumName.Text, txtSArtistName.Text, txtSReleaseDate.Text);
                if (txtResult.Text == "")
                {
                    lblError.Text = "Error! Invalide search. Please try again";
                }
            }
        }

        protected void btnBack_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the selection page
                Session["branchName"] = sBranchName;
                Session["branchID"] = sBranchID;
                Session["password"] = sPassword;
                Session["username"] = sUsername;
                Session["access"] = accesstype;
                Session["button"] = button;
                Server.Transfer("~/Selection.aspx");
                Response.Redirect("Selection.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Selection.aspx");
            }
        }

        #region gather all the information for the search result
        public void getProcut(string itemCode, string albumName, string artistName, string releaseDate)
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConne = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand Select = new MySqlCommand("SELECT * FROM pavanicadatabase.product WHERE productCode='" + itemCode + "' OR productArtist='" + artistName + "' OR productAlbum='" + albumName + "' OR productReleaseDate='" + releaseDate + "';", myConne);
                // Enableing the application to retreve data from the database
                MySqlDataReader Reader;
                // The connection is opened
                myConne.Open();
                Reader = Select.ExecuteReader();

                while (Reader.Read())
                {
                    pCode = Reader["productCode"].ToString();
                    artist = Reader["productArtist"].ToString();
                    album = Reader["productAlbum"].ToString();
                    rdate = Reader["productReleaseDate"].ToString();
                    rdate = ConvertDate(rdate);
                    getProductBranch(pCode);
                }
                myConne.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = "Error! " + ex.Message.ToString() + ", Please try again later";
            }
        }

        public void getProductBranch(string itemCode)
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand Select = new MySqlCommand("SELECT * FROM pavanicadatabase.branchproduct WHERE productCode='" + itemCode + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader Reader;
                // The connection is opened
                myConn.Open();
                Reader = Select.ExecuteReader();

                while (Reader.Read())
                {
                    pCode = Reader["productCode"].ToString();
                    branchCode = Reader["branchID"].ToString();
                    quantity = Reader["quantityAvailable"].ToString();
                    getBranch(branchCode);
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = "Error! " + ex.Message.ToString() + ", Please try again later";
            }
        }

        public void getBranch(string BranchCode)
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand Select = new MySqlCommand("SELECT * FROM pavanicadatabase.branch WHERE branchID='" + BranchCode + "';", myConn);
                // Enableing the application to retreve data from the database
                MySqlDataReader Reader;
                // The connection is opened
                myConn.Open();
                Reader = Select.ExecuteReader();

                while (Reader.Read())
                {
                    branchName = Reader["branchName"].ToString();
                    getResult();
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = "Error! " + ex.Message.ToString() + ", Please try again later";
            }
        }
        #endregion

        #region Compile the information into the search result
        public void getResult()
        {
            txtResult.Text = txtResult.Text + "Item Code: " + pCode + ",    Album Name: " + album + ",    Artist Name: " + artist + ",    Release Date: " + rdate + ",\nBranch Code: " + branchCode + ",    Branch Name: " + branchName + ",    Quanlity Available: " + quantity + "\n\n";
        }
        #endregion

        public string ConvertDate(string Date)
        {
            string Day;
            string Month;
            string Year;
            string totalDate;
            string value;
            int length;
            string date;

            date = Date;
            totalDate = date;
            length = totalDate.Length;
            for (int n = 0; n < length; n++)
            {
                value = date[n].ToString();
                if (value == "/")
                {
                    if (n == 1)
                    {
                        totalDate = "0" + totalDate;
                    }
                    else if (n == 3)
                    {
                        totalDate = totalDate.Insert(n, "0");
                    }
                }
            }

            Month = totalDate[0].ToString() + totalDate[1].ToString();
            Day = totalDate[3].ToString() + totalDate[4].ToString();
            Year = totalDate[6].ToString() + totalDate[7].ToString() + totalDate[8].ToString() + totalDate[9].ToString();

            Date = Year + "-" + Month + "-" + Day;
            return Date;
        }
    }
}