﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;

namespace WebApplication2
{
    public partial class WebForm13 : System.Web.UI.Page
    {
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        string sUsername;
        string sPassword;
        string accesstype;
        string button;

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                #region Get information
                sPassword = Session["password"].ToString();
                sUsername = Session["username"].ToString();
                accesstype = Session["access"].ToString();
                button = Session["button"].ToString();
                #endregion
            }
            catch (Exception ex)
            {
                // Do nothing
            }
        }

        public void GetBranchInfo(string BranchName)
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectComm = new MySqlCommand("SELECT * FROM pavanicadatabase.branch WHERE branchName='" + BranchName + "' ;", myConn);
                // Enableing the application to retrieve data from the database
                MySqlDataReader reader;
                // The connection is opened
                myConn.Open();
                reader = SelectComm.ExecuteReader();

                // Reading the selected data in the selected table
                while (reader.Read())
                {
                    // Testing whether the table has some data in it
                    if (reader.HasRows)
                    {
                        Session["branchName"] = BranchName;
                        Session["branchID"] = reader["branchID"].ToString();
                        Session["password"] = sPassword;
                        Session["username"] = sUsername;
                        Session["access"] = accesstype;
                        Session["button"] = button;
                        Server.Transfer("~/Selection.aspx");
                        Response.Redirect("Selection.aspx");
                    }
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString();
            }
        }

        protected void btnBloemfontein_Click1(object sender, ImageClickEventArgs e)
        {
            GetBranchInfo(btnBloemfontein.AlternateText);
        }

        protected void btnCapeTown_Click1(object sender, ImageClickEventArgs e)
        {
            GetBranchInfo(btnCapeTown.AlternateText);
        }

        protected void btnDurban_Click1(object sender, ImageClickEventArgs e)
        {
            GetBranchInfo(btnDurban.AlternateText);
        }

        protected void btnJohannesburg_Click1(object sender, ImageClickEventArgs e)
        {
            GetBranchInfo(btnJohannesburg.AlternateText);
        }

        protected void btnKimberley_Click1(object sender, ImageClickEventArgs e)
        {
            GetBranchInfo(btnKimberley.AlternateText);
        }

        protected void btnNelspruit_Click1(object sender, ImageClickEventArgs e)
        {
            GetBranchInfo(btnNelspruit.AlternateText);
        }

        protected void btnPortElizabeth_Click1(object sender, ImageClickEventArgs e)
        {
            GetBranchInfo(btnPortElizabeth.AlternateText);
        }

        protected void btnPotchefstroom_Click1(object sender, ImageClickEventArgs e)
        {
            GetBranchInfo(btnPotchefstroom.AlternateText);
        }

        protected void btnPretoria_Click1(object sender, ImageClickEventArgs e)
        {
            GetBranchInfo(btnPretoria.AlternateText);
        }

        protected void btnWitbank_Click1(object sender, ImageClickEventArgs e)
        {
            GetBranchInfo(btnWitbank.AlternateText);
        }

        protected void btnLogout_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the home page
                Response.Redirect("Home.aspx");
            }
            catch (Exception ex)
            {
                //do nothing
            }
        }
    }
}