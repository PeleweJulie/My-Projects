﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication2
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void ibtnHome_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the home page
                Response.Redirect("Home.aspx");
            }
            catch (Exception ex)
            {
                //Do nothing
            }
        }

        protected void ibtnTop10_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to redirect to the genres page
                Session["Top10"] = "Top10Button";
                Server.Transfer("~/Genre.aspx");
                Response.Redirect("Genre.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Genre.aspx");
            }            
        }

        protected void ibtnCharts_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                //try to regirect to the charts page
                Session["Top10"] = "Charts";
                Server.Transfer("~/Charts.aspx");
                Response.Redirect("Charts.aspx");
            }
            catch (Exception ex)
            {
                Response.Redirect("Charts.aspx");
            }
        }

        protected void lbtnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                //try to regirect to the access page
                Response.Redirect("Access.aspx");
            }
            catch (Exception ex)
            {
                //Do nothing
            }
        }
    }
}