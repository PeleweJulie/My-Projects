﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using MySql.Data.MySqlClient;
using System.Collections;

namespace WebApplication2
{
    public partial class Local_top_10 : System.Web.UI.Page
    {
        // The database connection string
        string connection = "datasource=localhost;port=3306;username=root;password=Root";

        string sGenre, sButton;
        string sBranch, sBranchID;
        string Product;
        int ten = 1;
        ArrayList Top10 = new ArrayList();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                sGenre = Session["genre"].ToString();
                sBranch = Session["branch"].ToString();
                sButton = Session["button"].ToString();
                lblTop10.Text = sBranch + " Top 10";

                if (sButton == "Local Charts")
                {
                    Local();
                }
                else if (sButton == "National Charts")
                {
                    National();
                }
            }
            catch
            {
                // Do nothing
            }
        }

        public void National()
        {
            if (sGenre == "All Genres")
            {
                #region display National top 10 of all genres
                try
                {
                    MySqlConnection myConn = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand SelectComm = new MySqlCommand("SELECT DISTINCT * FROM pavanicadatabase.nationalchart JOIN pavanicadatabase.product WHERE nationalchart.productCode = product.productCode AND nationalchart.Nsold != 0  ORDER BY Nsold DESC LIMIT 10;", myConn);
                    // Enableing the application to retrieve data from the database
                    MySqlDataReader reader;
                    // The connection is opened
                    myConn.Close();
                    myConn.Open();
                    reader = SelectComm.ExecuteReader();

                    // Reading the selected data in the selected table
                    while (reader.Read())
                    {
                        if (ten <= 10)
                        {
                            lbxTop10.Items.Add(ten.ToString() + " | Artist Name: " + reader["productArtist"].ToString() + " | Album Name: " + reader["productAlbum"].ToString() + " | Release Date: " + convertDate(reader["productReleaseDate"].ToString()) + " | Genre: " + reader["itemGenre"].ToString());
                            ten++;
                        }
                    }
                    myConn.Close();
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message.ToString() + ", please try again";
                }
                #endregion
            }
            else
            {
                #region display National top 10 of specified genre
                try
                {
                    MySqlConnection myConn = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand SelectComm = new MySqlCommand("SELECT DISTINCT * FROM pavanicadatabase.nationalchart JOIN pavanicadatabase.product WHERE nationalchart.productCode = product.productCode AND product.itemGenre = '" + sGenre + "' AND nationalchart.Nsold != 0 ORDER BY Nsold DESC LIMIT 10;", myConn);
                    // Enableing the application to retrieve data from the database
                    MySqlDataReader reader;
                    // The connection is opened
                    myConn.Close();
                    myConn.Open();
                    reader = SelectComm.ExecuteReader();

                    // Reading the selected data in the selected table
                    while (reader.Read())
                    {
                        if (ten <= 10)
                        {
                            lbxTop10.Items.Add(ten.ToString() + " | Artist Name: " + reader["productArtist"].ToString() + " | Album Name: " + reader["productAlbum"].ToString() + " | Release Date: " + convertDate(reader["productReleaseDate"].ToString()) + " | Genre: " + reader["itemGenre"].ToString());
                            ten++;
                        }
                    }
                    myConn.Close();
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message.ToString() + ", please try again";
                }
                #endregion
            }
        }

        public void Local()
        {
            getBarnchID();

            if (sGenre == "All Genres")
            {
                #region display local top 10 of all genres
                try
                {
                    MySqlConnection myConn = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand SelectComm = new MySqlCommand("SELECT DISTINCT * FROM pavanicadatabase.localchart JOIN pavanicadatabase.product WHERE localchart.productCode = product.productCode AND localchart.branchID = '" + sBranchID + "' AND localchart.Lsold != 0 ORDER BY Lsold DESC;", myConn);
                    // Enableing the application to retrieve data from the database
                    MySqlDataReader reader;
                    // The connection is opened
                    myConn.Close();
                    myConn.Open();
                    reader = SelectComm.ExecuteReader();

                    // Reading the selected data in the selected table
                    while (reader.Read())
                    {
                        if (ten <= 10)
                        {
                            lbxTop10.Items.Add(ten.ToString() + " | Artist Name: " + reader["productArtist"].ToString() + " | Album Name: " + reader["productAlbum"].ToString() + " | Release Date: " + convertDate(reader["productReleaseDate"].ToString()) + " | Genre: " + reader["itemGenre"].ToString());
                            ten++;
                        }
                    }
                    myConn.Close();
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message.ToString() + ", please try again";
                }
                #endregion
            }
            else
            {
                #region display local top 10 of specified genre
                try
                {
                    MySqlConnection myConn = new MySqlConnection(connection);
                    // The Select statement
                    MySqlCommand SelectComm = new MySqlCommand("SELECT DISTINCT * FROM pavanicadatabase.localchart JOIN pavanicadatabase.product WHERE localchart.productCode = product.productCode AND localchart.branchID = '" + sBranchID + "' AND product.itemGenre = '" + sGenre + "' AND localchart.Lsold != 0 ORDER BY Lsold DESC;", myConn);
                    // Enableing the application to retrieve data from the database
                    MySqlDataReader reader;
                    // The connection is opened
                    myConn.Close();
                    myConn.Open();
                    reader = SelectComm.ExecuteReader();

                    // Reading the selected data in the selected table
                    while (reader.Read())
                    {
                        if (ten <= 10)
                        {
                            lbxTop10.Items.Add(ten.ToString() + " | Artist Name: " + reader["productArtist"].ToString() + " | Album Name: " + reader["productAlbum"].ToString() + " | Release Date: " + convertDate(reader["productReleaseDate"].ToString()) + " | Genre: " + reader["itemGenre"].ToString());
                            ten++;
                        }
                    }
                    myConn.Close();
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.Message.ToString() + ", please try again";
                }
                #endregion
            }
        }        
        
        public void getBarnchID()
        {
            try
            {
                // Connecting to the database using the database connection string
                MySqlConnection myConn = new MySqlConnection(connection);
                // The Select statement
                MySqlCommand SelectComm = new MySqlCommand("SELECT * FROM pavanicadatabase.branch WHERE branchName='" + sBranch + "' ;", myConn);
                // Enableing the application to retrieve data from the database
                MySqlDataReader reader;
                // The connection is opened
                myConn.Close();
                myConn.Open();
                reader = SelectComm.ExecuteReader();

                // Reading the selected data in the selected table
                while (reader.Read())
                {
                    sBranchID = reader["branchID"].ToString();
                }
                myConn.Close();
            }
            catch (Exception ex)
            {
                lblError.Text = ex.Message.ToString() + ", please try again";
            }
        }

        public string convertDate(string date)
        {
            string Day;
            string Month;
            string Year;
            string totalDate;
            string value;
            int length;

            totalDate = date;
            length = totalDate.Length;
            for (int n = 0; n < length; n++)
            {
                value = date[n].ToString();
                if (value == "/")
                {
                    if (n == 1)
                    {
                        totalDate = "0" + totalDate;
                    }
                    else if (n == 3)
                    {
                        totalDate = totalDate.Insert(n, "0");
                    }
                }
            }

            Month = totalDate[0].ToString() + totalDate[1].ToString();
            Day = totalDate[3].ToString() + totalDate[4].ToString();
            Year = totalDate[6].ToString() + totalDate[7].ToString() + totalDate[8].ToString() + totalDate[9].ToString();

            date = Year + "-" + Month + "-" + Day;
            return date;
        }

        protected void ibtnHome_Click(object sender, ImageClickEventArgs e)
        {
            try
            {
                if (sButton == "Local Charts")
                {
                    //try to redirect to the genre page
                    Response.Redirect("Genre.aspx");
                }
                else
                {
                    //try to redirect to the home page
                    Response.Redirect("Home.aspx");
                }
            }
            catch(Exception ex)
            {
                //do nothing
            }
        }
    }
}