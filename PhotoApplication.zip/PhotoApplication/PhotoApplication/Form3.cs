﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using System.Data.ConnectionUI;
using System.Data.SqlClient;
using Microsoft.Win32;
using System.Security.Permissions;
using System.Configuration;
using System.Security.Principal;
using System.IO;
[assembly: PermissionSetAttribute(SecurityAction.RequestMinimum, Name = "FullTrust")]

namespace PhotoApplication
{
    public partial class Form3 : Form
    {
        DataSet ds;
        //private Dictionary<string, object> Employee;

        // Variable for storing the image name, path chosen from file dialog
        private String _EmployeeId = "";


        private object ConfigurationManager;
        private string ConnectionString;
        private Log.Logger TraceNew = new Log.Logger(@"c:\EOH\PhotoApp");

        DataTable results = null;
        private string appPath;

        public string connectionString
        {
            get
            {
                return ConnectionString;

            }
        }
        public Form3()
        {
            InitializeComponent();

        }

        private void FillData()
        {



            using (BesData2009.SqlCommands SQ = new BesData2009.SqlCommands(ConnectionString, TraceNew))
            {
                string SQL = @"select Employee.EmployeeId, Employee.PayrollNumber, Employee.FirstNames, Employee.LastName, EmployeeImage.EImage
from Employee
INNER JOIN EmployeeImage
ON Employee.EmployeeId = EmployeeImage.EmployeeID
ORDER BY Employee.EmployeeId ";
                results = SQ.QuerySqlDataTable(SQL, "Results");

            }

            foreach (DataRow dr in results.Rows)
            {
                listBox1.Items.Add(dr["EmployeeId"].ToString());





            }
        }
        private object SQLconnectionDB()
        {
            throw new NotImplementedException();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {



             SaveFileDialog saver = new SaveFileDialog();
            saver.FileName = textBox3.Text;
             DialogResult LocRes = saver.ShowDialog();
             string[] filesToOpen = null;
             if (LocRes == DialogResult.OK)
           
             pictureBox1.Image.Save(saver.FileName + ".jpg");

            // MessageBox.Show("Image saved successfully");


        }

        private void Form3_Load_1(object sender, EventArgs e)
        {

            Form1 frm = new Form1();
            frm.ShowDialog();
            ConnectionString = frm.connectionString;
            FillData();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.Enabled = false;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                // Instantiate File Dialog box
                FileDialog fileDlg = new OpenFileDialog();

                // Set the initial directory
                fileDlg.InitialDirectory =
                "C:\\Users\\User\\Desktop\\EmployeeImages";

                // Filter image(.jpg, .bmp, .gif) files only
                fileDlg.Filter = "Image File (*.jpg;)|*.jpg;*";

                // Restores the current directory before closing
                fileDlg.RestoreDirectory = true;

                // When file is selected from the File Dialog
                if (fileDlg.ShowDialog() == DialogResult.OK)
                {
                    // Store the name of selected file into a variable
                    _EmployeeId = fileDlg.FileName;

                    string pr = "";//12345
                                   //get number if 12345.jpg  get 12345
                    results.Rows.Find("Payrollnumber = '" + pr + "'");
                    //look at returned rows
                    //get employeeid
                    listBox1.SelectedItem = "EmployeeId";


                    // Create a bitmap for selected image
                    Bitmap newImage = new Bitmap(_EmployeeId);

                    // Fit the image to the size of picture box
                    pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;

                    // Show the bitmap in picture box
                    pictureBox1.Image = (Image)newImage;

                }

                // No Image chosen
                fileDlg = null;
            }
            catch (System.ArgumentException ex)
            {
                // Display error message, if image is invalid
                _EmployeeId = "";
                System.Windows.Forms.MessageBox.Show(ex.ToString());
            }
            catch (Exception ex)
            {
                // Display error message
                System.Windows.Forms.MessageBox.Show(ex.ToString());
            }
        }



        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            if (pictureBox1.Image != null)
            {
                pictureBox1.Image.Dispose();
            }
            FileStream fs = new FileStream("image.jpg", FileMode.Create);
            listBox1.Click += new EventHandler(listBox1_SelectedIndexChanged);
            {
                foreach (DataRow row in results.Rows)
                {
                    if (row[0].ToString() == listBox1.SelectedItem.ToString())
                    {
                        textBox1.Text = row["FirstNames"].ToString();
                        textBox2.Text = row["LastName"].ToString();
                        textBox3.Text = row["PayrollNumber"].ToString();
                        byte[] blob = (byte[])row[4];


                        fs.Write(blob, 0, blob.Length);
                        fs.Close();
                        fs = null;


                        pictureBox1.Image = Image.FromFile("image.jpg");
                        pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                        pictureBox1.Refresh();

                    }

                }

            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox3.Enabled = false;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Form5 frm = new Form5();
            frm.ConnectionString = connectionString;
            frm.ShowDialog();
        }
    }
}
    





        

      
    


    


