﻿namespace PhotoApplication
{
    internal class SqlConnectionDB
    {
    }
}