﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PhotoApplication
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private string Connectionstring = "";



        private Log.Logger TraceNew = new Log.Logger(@"c:\EOH\PhotoApp");
        private void Form2_Load(object sender, EventArgs e)
        {
            Form1 frm = new Form1();
            frm.ShowDialog();
            Connectionstring = frm.connectionString;
        }

        private void butQuery_Click(object sender, EventArgs e)
        {
            DataTable Res = QueryResults(tbQuery.Text);
            dgResults.DataSource = Res;

        }

        private DataTable QueryResults(string Query)
        {
            DataTable results = null;
            using (BesData2009.SqlCommands SQ = new BesData2009.SqlCommands(Connectionstring, TraceNew))
            {
                string SQL = Query;
                results = SQ.QuerySqlDataTable(SQL,"Results");

            }
            return results;

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Form3 newform = new Form3();
            this.Hide();
            newform.ShowDialog();
            this.Show();
        }

        private void tbQuery_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgResults_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }

}
