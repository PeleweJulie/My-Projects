﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace PhotoApplication
{
    public partial class Form5 : Form
    {
        public string ConnectionString { get; set; }
        private Log.Logger TraceNew = new Log.Logger(@"c:\EOH\PhotoApp");
        DataSet ds;
        SqlConnection con;
        SqlDataAdapter adapt;
        DataTable results = null;

        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            using (BesData2009.SqlCommands SQ = new BesData2009.SqlCommands(ConnectionString, TraceNew))
            { 
                string SQL = "select EmployeeId, PayrollNumber, FirstNames, LastName from Employee";
                results = SQ.QuerySqlDataTable(SQL, "Results");
            }
            
            dataGridView1.DataSource = results;


            comboBox1.Items.Add("EmployeeId");
            comboBox1.Items.Add("PayrollNmber");
            comboBox1.Items.Add("FirstNames");
            comboBox1.Items.Add("LastName");
            var item = this.comboBox1.GetItemText(this.comboBox1.SelectedItem);
            //MessageBox.Show(item);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            using (BesData2009.SqlCommands SQ = new BesData2009.SqlCommands(ConnectionString, TraceNew))
            {
                string SQL = "select * from Employee where EmployeeId like '" + textBox1.Text + "%'";
                results = SQ.QuerySqlDataTable(SQL, "Results");
            }
                
            dataGridView1.DataSource = results;
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.Enabled = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            


        }
    }
}
