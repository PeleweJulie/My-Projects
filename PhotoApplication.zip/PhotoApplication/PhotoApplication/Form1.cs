﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//using System.Data.ConnectionUI;
using System.Data.SqlClient;
using Microsoft.Win32;
using System.Security.Permissions;
using System.Configuration;
using System.Security.Principal;
[assembly: PermissionSetAttribute(SecurityAction.RequestMinimum, Name = "FullTrust")]

namespace PhotoApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {



            InitializeComponent();
            DataTable dt = System.Data.Sql.SqlDataSourceEnumerator.Instance.GetDataSources();
            foreach (DataRow dr in dt.Rows)
            {
                string str = dr["ServerName"].ToString();
                if (dr["InstanceName"].ToString().Trim().Length > 0)
                    str = str + @"\" + dr["InstanceName"].ToString();
                cdServer.Items.Add(str);

            }
        }
        private string ConnectionString = "";
        public string connectionString
        {
            get
            {
                return ConnectionString;

            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {



//=======================================================
//In a specific event, place the following.
            try
            {
                string a;
                a = System.Security.Principal.WindowsIdentity.GetCurrent().Name.ToString();

            }
            catch { }

//MessageBox.Show(a.ToString());      
            


        }


        private void button1_Click(object sender, EventArgs e)
        {
            button2.Enabled = false;
            try
            {
                cbDataBase.Items.Clear();


            }
            catch { }
            try
            {
                using (SqlConnection con = new SqlConnection(SQLconnection().ConnectionString))
                {
                    con.Open();


                    DataTable databases = con.GetSchema("Databases");
                    foreach (DataRow dr in databases.Rows)
                    {
                        cbDataBase.Items.Add(dr["database_name"].ToString());

                    }




                }

            }

            catch (Exception eee)
            {
                string ee = eee.ToString();
            }
        }
        private SqlConnectionStringBuilder SQLconnection()
        {
            SqlConnectionStringBuilder conn = new SqlConnectionStringBuilder();
            conn.DataSource = cdServer.Text;
            conn.IntegratedSecurity = cbIntegrated.Checked;
            conn.UserID = tbUserName.Text;
            conn.Password = tbPassword.Text;
            // conn.InitialCatalog = "DBName";
            return conn;

        }
        private SqlConnectionStringBuilder SQLconnectionDB()
        {
            SqlConnectionStringBuilder conn = new SqlConnectionStringBuilder();
            conn.DataSource = cdServer.Text;
            conn.IntegratedSecurity = cbIntegrated.Checked;
            conn.UserID = tbUserName.Text;
            conn.Password = tbPassword.Text;
            conn.InitialCatalog = cbDataBase.Text;
            return conn;

        }

        private void button2_Click(object sender, EventArgs e)
        {

            ConnectionString = SQLconnectionDB().ToString();
            this.DialogResult = DialogResult.OK;
                        

            
        }

        private void cdServer_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                cbDataBase.Items.Clear();
            }
            catch { }
        }

        private void cbDataBase_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbDataBase.SelectedIndex > 0)
                button2.Enabled = true;
            else
                button2.Enabled = false;
        }
    }
}
