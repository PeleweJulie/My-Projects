﻿using System;
using System.Configuration;
using System.Globalization;
using System.IO;

namespace TraceLog
{
    public class TraceNeww
    {
        public static void WriteLine(string Record)
        {
            bool sta = false;
            int cnt = 0;
            while (!sta)
            {
                if (cnt > 100)
                    break;
                if (cnt > 0)
                    System.Threading.Thread.Sleep(10);
                cnt++;

                try
                {
                    //this is a test
                    string lgdir = "";
                    try
                    {
                        string path = @"C:\EOH";
                        try
                        {
                            path = ConfigurationManager.AppSettings["BLICKDIR"];
                        }
                        catch { }
                        if (path.Length == 0)
                            path = @"C:\EOH SBT";

                        lgdir = path + "\\Log\\";
                        Directory.CreateDirectory(lgdir);
                    }
                    catch { }
                    DateTime dt = DateTime.Now;
                    string TME = dt.Ticks.ToString(CultureInfo.InvariantCulture);
                    string DTE = dt.ToString("yyyyMMMdd");
                    string logfle = lgdir + "LOG" + DTE + ".log";
                    string DDD = DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture);
 
                    File.AppendAllText(logfle, DDD + " " + Record);
                    sta = true;
                }
                catch(Exception e) {
                    string str = e.ToString();
                }
            }
        }

        public static void WriteLineDir(string Record, string Dir)
        {
            bool sta = false;
            int cnt = 0;
            while (!sta)
            {
                if (cnt > 100)
                    break;
                if (cnt > 0)
                    System.Threading.Thread.Sleep(10);
                cnt++;

                try
                {
                    //this is a test
                    string lgdir = "";
                    try
                    {
                        string path = @"C:\EOH";
                        try
                        {
                            path = ConfigurationManager.AppSettings["BLICKDIR"];
                        }
                        catch { }
                        if (path.Length == 0)
                            path = @"C:\EOH SBT";

                        lgdir = path + "\\Log\\" + Dir + "\\";
                       if(! Directory.Exists(lgdir))
                         Directory.CreateDirectory(lgdir);
                    }
                    catch { }
                    DateTime dt = DateTime.Now;
                    string DTE = dt.ToString("yyyyMMMdd");
                    string logfle = lgdir + "LOG" + DTE + ".log";
                    string DDD = DateTime.Now.ToString("HH:mm:ss");
                    File.AppendAllText(logfle, DDD + " " + Record);

                    sta = true;
                }
                catch { }
            }
        }

        public static void WriteLine(string Record, string Operation)
        {
            try
            {
                string lgdir = "";
                try
                {
                    string path = @"C:\EOH";
                    try
                    {
                        path = ConfigurationManager.AppSettings["BLICKDIR"];
                    }
                    catch { }
                    if (path.Length == 0)
                        path = @"C:\EOH SBT";

                    lgdir = path + "\\Log\\";
                    Directory.CreateDirectory(lgdir);
                }
                catch { }
                DateTime dt = DateTime.Now;
                string TME = dt.Ticks.ToString(CultureInfo.InvariantCulture);
                string DTE = dt.ToString("yyyyMMMdd");
                string logfle = lgdir + "LOG" + DTE + ".log";
                string DDD = DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture);
                TextWriter output = File.AppendText(logfle);
                File.AppendAllText(logfle, DDD + " " + Record);
            }
            catch { }
        }

        public static void WriteLineIf(bool sta, string Record, string Operation)
        {
            if (!sta)
                return;
            try
            {
                string lgdir = "";
                try
                {
                    string path = @"C:\EOH";
                    try
                    {
                        path = ConfigurationManager.AppSettings["BLICKDIR"];
                    }
                    catch { }
                    if (path.Length == 0)
                        path = @"C:\EOH SBT";

                    lgdir = path + "\\Log\\";
                    Directory.CreateDirectory(lgdir);
                }
                catch { }
                DateTime dt = DateTime.Now;
                string TME = dt.Ticks.ToString(CultureInfo.InvariantCulture);
                string DTE = dt.ToString("yyyyMMMdd");
                string logfle = lgdir + "LOG" + DTE + ".log";
                string DDD = DateTime.Now.ToString("HH:mm:ss", CultureInfo.InvariantCulture);
                File.AppendAllText(logfle, DDD + " " + Record);
            }
            catch { }
        }

        public static void RemoveExpired()
        {
            try
            {
                string lgdir = "";
                try
                {
                    string path = @"C:\EOH";
                    try
                    {
                        path = ConfigurationManager.AppSettings["BLICKDIR"];
                    }
                    catch { }
                    if (path.Length == 0)
                        path = @"C:\EOH SBT";

                    lgdir = path + "\\Log\\";
                    Directory.CreateDirectory(lgdir);
                }
                catch { }

                string[] FLE = Directory.GetFiles(lgdir, "*.log");
                foreach (string FF in FLE)
                {
                    try
                    {
                        if (File.GetLastWriteTime(FF) < DateTime.Now.AddDays(-14))
                            File.Delete(FF);
                    }
                    catch { }
                }
            }
            catch { }
        }
        public static void RemoveExpiredDIR(string Dir)
        {
            try
            {
                string lgdir = "";
                try
                {
                    string path = @"C:\EOH";
                    try
                    {
                        path = ConfigurationManager.AppSettings["BLICKDIR"];
                    }
                    catch { }
                    if (path.Length == 0)
                        path = @"C:\EOH SBT";


                    lgdir = path + "\\Log\\" + Dir + "\\";
                    Directory.CreateDirectory(lgdir);
                }
                catch { }

                string[] FLE = Directory.GetFiles(lgdir, "*.log");
                foreach (string FF in FLE)
                {
                    try
                    {
                        if (File.GetLastWriteTime(FF) < DateTime.Now.AddDays(-14))
                            File.Delete(FF);
                    }
                    catch { }
                }
            }
            catch { }
        }
    }
}