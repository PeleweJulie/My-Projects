﻿
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Log
{
    public interface ILogger
    {
        void WriteLine(string msg);
        void WriteLineIf(bool sta,string msg,string Function);
        void WriteLine(string msg, string Function);
        void WriteLineDir(string msg,string Dir);
        void WriteError(string errorMsg);
        void WriteError(string errorObject, string errorAction, string errorMsg);
        void WriteWarning(string errorObject, string errorAction, string errorMsg);
    }
    internal class Param
    {
        internal enum LogType { Info, Warning, Error, SimpleError,InfoNew };

        internal LogType Ltype { get; set; }  // Type of log
        internal string Msg { get; set; }     // Message
        internal string Action { get; set; }  // Action when error or warning occurs (optional)
        internal string Obj { get; set; }     // Object that was processed whend error or warning occurs (optional)
        internal string Dir { get; set; }
        internal Param()
        {
            Ltype = LogType.Info;
            Msg = "";
        }
        internal Param(LogType logType, string logMsg)
        {
            Ltype = logType;
            Msg = logMsg;
        }
        internal Param(LogType logType, string logMsg,string dir)
        {
            Ltype = logType;
            Msg = logMsg;
            Dir = dir;
        }
        internal Param(LogType logType, string logMsg, string logAction, string logObj)
        {
            Ltype = logType;
            Msg = logMsg;
            Action = logAction;
            Obj = logObj;
        }
    }


    // Reentrant Logger written with Producer/Consumer pattern.
    // It creates a thread that receives write commands through a Queue (a BlockingCollection).
    // The user of this log has just to call Logger.WriteLine() and the log is transparently written asynchronously.

    public class Logger : ILogger
    {
        BlockingCollection<Param> bc = new BlockingCollection<Param>();

        // Constructor create the thread that wait for work on .GetConsumingEnumerable()
        public Logger(string FileName)
        {
            Task.Factory.StartNew(() =>
            {
                foreach (Param p in bc.GetConsumingEnumerable())
                {
                    switch (p.Ltype)
                    {
                        case Log.Param.LogType.Info:
                            try
                            {
                                const string LINE_MSG = "[{0}] {1}";
                            if (!Directory.Exists(FileName ))
                                Directory.CreateDirectory(FileName );
                            
                                using (StreamWriter str = File.AppendText(FileName + @"\" + DateTime.Now.ToString("dd-MM-yyyy") + ".log"))
                                {
                                    str.WriteLine(String.Format(LINE_MSG, LogTimeStamp(), p.Msg));
                                    str.Close();
                                }
                            }
                            catch(Exception e) {
                                TraceLog.TraceNeww.WriteLineDir("Log write exception " + e.ToString(), "Logerror");
                            }
                            System.Threading.Thread.Sleep(100);

                            break;
                        case Log.Param.LogType.InfoNew:
                            try
                            {
                                const string LINE_MSG_new = "[{0}] {1}";
                                if (!Directory.Exists(FileName + @"\" + p.Dir))
                                    Directory.CreateDirectory(FileName + @"\" + p.Dir);
                                using (StreamWriter str1 = File.AppendText(FileName + @"\" + p.Dir + @"\" + DateTime.Now.ToString("dd-MM-yyyy") + ".log"))
                                {
                                    str1.WriteLine(String.Format(LINE_MSG_new, LogTimeStamp(), p.Msg));
                                    str1.Close();
                                }
                            }
                            catch (Exception ee)
                            {
                                TraceLog.TraceNeww.WriteLineDir("Log write exception " + ee.ToString(),"Logerror");

                            }
                            System.Threading.Thread.Sleep(100);

                            break;
                        case Log.Param.LogType.Warning:
                            const string WARNING_MSG = "[{3}] * Warning {0} (Action {1} on {2})";
                            Console.WriteLine(String.Format(WARNING_MSG, p.Msg, p.Action, p.Obj, LogTimeStamp()));
                            break;
                        case Log.Param.LogType.Error:
                            const string ERROR_MSG = "[{3}] *** Error {0} (Action {1} on {2})";
                            Console.WriteLine(String.Format(ERROR_MSG, p.Msg, p.Action, p.Obj, LogTimeStamp()));
                            break;
                        case Log.Param.LogType.SimpleError:
                            const string ERROR_MSG_SIMPLE = "[{0}] *** Error {1}";
                            Console.WriteLine(String.Format(ERROR_MSG_SIMPLE, LogTimeStamp(), p.Msg));
                            break;
                        default:
                            
                            break;
                    }
                }
            });
        }

        ~Logger()
        {
            // Free the writing thread
            bc.CompleteAdding();
        }

        // Just call this method to log something (it will return quickly because it just queue the work with bc.Add(p))
        public void WriteLine(string msg)
        {
            Param p = new Param(Log.Param.LogType.Info, msg);
            bc.Add(p);
        }
        public void WriteLine(string msg,string Function)
        {
            Param p = new Param(Log.Param.LogType.Info, Function +" - "+msg);
            bc.Add(p);
        }
        public void WriteLineIf(bool sta,string msg, string Function)
        {
            if (!sta)
                return;
            Param p = new Param(Log.Param.LogType.Info, Function + " - " + msg);
            bc.Add(p);
        }
        public void WriteLineDir(string msg,string subDir)
        {
            Param p = new Param(Log.Param.LogType.InfoNew, msg,subDir);
            bc.Add(p);
        }

        public void WriteError(string errorMsg)
        {
            Param p = new Param(Log.Param.LogType.SimpleError, errorMsg);
            bc.Add(p);
        }

        public void WriteError(string errorObject, string errorAction, string errorMsg)
        {
            Param p = new Param(Log.Param.LogType.Error, errorMsg, errorAction, errorObject);
            bc.Add(p);
        }

        public void WriteWarning(string errorObject, string errorAction, string errorMsg)
        {
            Param p = new Param(Log.Param.LogType.Warning, errorMsg, errorAction, errorObject);
            bc.Add(p);
        }

        string LogTimeStamp()
        {
            DateTime now = DateTime.Now;
            return now.ToString("dd-MM-yyyy HH:mm:ss");
        }

    }
}
