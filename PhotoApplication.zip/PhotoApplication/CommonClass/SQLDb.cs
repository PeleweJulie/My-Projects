using System;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using Microsoft.Win32;
using TraceLog;


[assembly: CLSCompliant(true)]

namespace BesData2009
{
    public class SqlCommands : IDisposable
    {
        private string dns = "";
        private SqlConnection SQLConn = null;
        private SqlCommand SQLComm;
        private SqlTransaction transaction = null;
        private bool connected = false;
        private Log.Logger TraceNew;
        # region Constructor

        // The class constructor.
        // public SqlCommands(TraceNew)
        public SqlCommands(Log.Logger Tracenew)
        {
            //  this.handle = handle;
            TraceNew = Tracenew;
            try
            {
                bool reg = true;
                try
                {
                    if (ConfigurationManager.AppSettings["UseReg"].ToUpper() != "TRUE")
                        reg = false;
                }
                catch { }
                if (!reg)
                    this.ConnectionParameters = BESEnc.Encrypt.decryptString((ConfigurationManager.AppSettings["dsn"]), "BBEESS");
                else
                {
                    RegistryKey rk = Registry.LocalMachine;
                    rk = rk.OpenSubKey("SOFTWARE\\Stanley");
                    if (rk == null)
                        dns = BESEnc.Encrypt.decryptString(ConfigurationManager.AppSettings["Main.Connectionstring"].ToString(), "BBEESS");
                    else
                        dns = BESEnc.Encrypt.decryptString(rk.GetValue("ConnectionString").ToString(), "BBEESS");
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Initialize sql error " + x, "SqlCommands");
            }

        }

        public SqlCommands(int cnt, Log.Logger Tracenew)
        {
            //  this.handle = handle;

            try
            {
                bool reg = true;
                try
                {
                    if (ConfigurationManager.AppSettings["UseReg"].ToUpper() != "TRUE")
                        reg = false;
                }
                catch { }
                if (!reg)
                    this.ConnectionParameters = BESEnc.Encrypt.decryptString((ConfigurationManager.AppSettings["dsn"]), "BBEESS");
                else
                {
                    RegistryKey rk = Registry.LocalMachine;
                    rk = rk.OpenSubKey("SOFTWARE\\Stanley");
                    if (rk == null)
                        dns = BESEnc.Encrypt.decryptString(ConfigurationManager.AppSettings["Main.Connectionstring"].ToString(), "BBEESS");
                    else
                        dns = BESEnc.Encrypt.decryptString(rk.GetValue("ConnectionString" + cnt).ToString(), "BBEESS");
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Initialize sql error " + x, "SqlCommands");
            }

        }

        public SqlCommands(string Connectionstring, Log.Logger Tracenew)
        {
            TraceNew = Tracenew;
            this.ConnectionParameters = Connectionstring;
        }

        # endregion
        # region Database Connection

        public string ConnectionParameters
        {
            get { return dns; }
            set { dns = value; }
        }

        /// <summary>
        /// Connect To database
        /// </summary>
        /// <returns>status of connection</returns>
        public bool DBConnection()
        {
            bool con = true;
            try
            {
                if (!connected)
                {
                    SQLConn = new SqlConnection(dns);
                    SQLConn.Open();
                    SQLComm = new SqlCommand();
                    SQLComm.Connection = SQLConn;
                    SQLComm.CommandTimeout = 6000;
                    con = true;
                    connected = true;
                }
            }
            catch (Exception xx)
            {
                TraceNeww.WriteLineDir("SQL Connection Error" + xx.ToString(), "SQLERROR");
                TraceNew.WriteLine("Connection Error" + xx, "DBConnection");
                TraceNew.WriteLine("dns - " + dns, "DBConnection");
                con = false;
            }

            return con;
        }

        //Disconnect from Database
        public void DBDisconnect()
        {
            try
            {
                //if (Disconnect)
                //{
                SQLConn.Close();
                SQLConn = null;
                connected = false;
                //}
            }
            catch { }
        }

        #endregion
        #region Transaction Settings
        /// <summary>
        /// Starts a transaction.
        /// The transaction will need to be commited before Information is stored in the database
        /// Otherwise it will be rolled back
        /// </summary>

        public void startTransaction()
        {
            transaction = SQLConn.BeginTransaction();
            SQLComm.Transaction = transaction;
        }

        /// <summary>
        /// Perform commit of Records
        /// </summary>
        public void CommitTransaction()
        {
            transaction.Commit();
        }

        /// <summary>
        /// Performs Roll Back of Insert
        /// </summary>
        public void RollbackTransaction()
        {
            transaction.Rollback();
        }

        #endregion

        #region Query Methods

        //Perform SQL Query from database from SQL statement 'Query'
        //Returns dataset of results
        public DataSet QuerySql(string query, string dsName)
        {
            DataSet ds = new DataSet(dsName);
            ds.Locale = CultureInfo.InvariantCulture;
            try
            {
                if (!DBConnection()) return ds;
                SQLComm.CommandText = query;
                SqlDataAdapter Da = new SqlDataAdapter();
                Da.SelectCommand = SQLComm;
                Da.Fill(ds, dsName);
            }
            catch (Exception xx)
            {
                TraceNew.WriteLine("Query Error" + xx, "QuerySql");
                TraceNew.WriteLine("Query - " + query, "QuerySql");
            }

            DBDisconnect();
            return ds;
        }

        /// <summary>
        /// Query Database
        /// </summary>
        /// <param name="query">SQL query</param>
        /// <param name="dsName">Name of DataTable to be populated</param>
        /// <returns>DataTable Containing the results</returns>
        public DataTable QuerySqlDataTable(string query, string dsName)
        {
            DataTable ds = new DataTable(dsName);
            ds.Locale = CultureInfo.InvariantCulture;
            try
            {
                if (!DBConnection()) return ds;
                SQLComm.CommandText = query;
                SqlDataAdapter Da = new SqlDataAdapter();
                Da.SelectCommand = SQLComm;
                Da.Fill(ds);
            }
            catch (Exception xx)
            {
                TraceNew.WriteLine("Query Error" + xx, "QuerySqlDataTable");
                TraceNew.WriteLine("Query - " + query, "QuerySqlDataTable");
            }
            DBDisconnect();
            return ds;
        }

        /// <summary>
        /// Query Database Without Disconnecting
        /// Used with batch inserts etc...
        /// </summary>
        /// <param name="query">SQL query</param>
        /// <param name="dsName">Name of DataTable to be populated</param>
        /// <returns>DataTable Containing the results</returns>
        public DataTable QuerySqlDataTableND(string query, string dsName)
        {
            DataTable ds = new DataTable(dsName);
            ds.Locale = CultureInfo.InvariantCulture;
            try
            {
                if (!DBConnection()) return ds;
                SQLComm.CommandText = query;
                SqlDataAdapter Da = new SqlDataAdapter();
                Da.SelectCommand = SQLComm;
                Da.Fill(ds);
            }
            catch (Exception xx)
            {
                TraceNew.WriteLine("Query Error" + xx, "QuerySqlDataTableND");
                TraceNew.WriteLine("Query - " + query, "QuerySqlDataTableND");
            }

            return ds;
        }

        /// <summary>
        /// Query's a sql Database returning a string array of results
        /// </summary>
        /// <param name="query">SQL Query</param>
        /// <returns>String array of results</returns>
        public string[] QuerySqlString(string query)
        {

            string Command = query;
            string[] Employee = null;
            try
            {
                DBConnection();
                SQLComm.CommandText = Command;
                SqlDataReader myReader;
                myReader = SQLComm.ExecuteReader();
                int len = myReader.FieldCount;
                Employee = new string[len];
                while (myReader.Read())
                {
                    for (int i = 0; i < len; i++) Employee[i] = "" + myReader.GetValue(i);
                }
            }
            catch (Exception xx)
            {
                TraceNew.WriteLine("Query Error" + xx, "QuerySqlString");
                TraceNew.WriteLine("Query - " + query, "QuerySqlString");
            }

            DBDisconnect();
            return Employee;
        }

        /// <summary>
        /// Query's a sql Database returning a string array of results Does Not disconnect
        /// Used when connection needs to remain open like with batch inserts
        /// </summary>
        /// <param name="query">SQL Query</param>
        /// <returns>String array of results</returns>
        public string[] QuerySqlStringND(string query)
        {
            string[] Employee = null;

            try
            {
                string Command = query;

                DBConnection();
                SQLComm.CommandText = Command;
                SqlDataReader myReader;
                myReader = SQLComm.ExecuteReader();
                int len = myReader.FieldCount;
                Employee = new string[len];
                while (myReader.Read())
                {
                    for (int i = 0; i < len; i++) Employee[i] = "" + myReader.GetValue(i);
                }
            }
            catch (Exception xx)
            {
                TraceNew.WriteLine("Query Error" + xx, "QuerySqlStringND");
                TraceNew.WriteLine("Query - " + query, "QuerySqlStringND");
            }
            DBDisconnect();
            return Employee;
        }

        #endregion
        #region Execute Methods

        //Perform SQL Execute Statement
        //Returns Integer value of records affected
        /// <summary>
        /// Executes a SQL command
        /// </summary>
        /// <param name="command">SQL statement to execute</param>
        /// <returns>Integer of number of rows affected</returns>
        public int ExecuteSql(string command)
        {
            int resCnt = -1;
            try
            {
                if (!DBConnection()) return resCnt;
                SQLComm.CommandText = command;
                resCnt = SQLComm.ExecuteNonQuery();
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "ExecuteSql");
                TraceNew.WriteLine("Query - " + command, "ExecuteSql");
            }
            if (resCnt == -1)
            {
                TraceNew.WriteLine("Execute error (-1)", "ExecuteSql");
                TraceNew.WriteLine("Query - " + command, "ExecuteSql");
            }

            DBDisconnect();
            return resCnt;
        }

        /// <summary>
        /// Executes a SQL command without disconnecting
        /// Used when working on temp tables inserted by a batch Insert
        /// </summary>
        /// <param name="command">SQL statement to execute</param>
        /// <returns>Integer of number of rows affected</returns>
        public int ExecuteSqlNoDisconnect(string command)
        {
            int resCnt = -1;
            try
            {
                if (!DBConnection()) return resCnt;
                SQLComm.CommandText = command;
                resCnt = SQLComm.ExecuteNonQuery();
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "ExecuteSql");
                TraceNew.WriteLine("Query - " + command, "ExecuteSql");
            }
            if (resCnt == -1)
            {
                TraceNew.WriteLine("Execute error (-1)", "ExecuteSql");
                TraceNew.WriteLine("Query - " + command, "ExecuteSql");
            }
            return resCnt;
        }

        public int InsertImage(string employeeId, byte[] image)
        {
            DBConnection();

            try
            {
                SQLComm = new SqlCommand("update EmployeeImage set EImage = @EImage where EmployeeID = @Employee", this.SQLConn);
                SqlParameter EMP = new SqlParameter("@Employee", SqlDbType.Int, 4);
                EMP.Value = employeeId;
                SQLComm.Parameters.Add(EMP);
                SqlParameter Img = new SqlParameter("@EImage", SqlDbType.Image, 2147483647);
                Img.Value = image;
                SQLComm.Parameters.Add(Img);
                int a = SQLComm.ExecuteNonQuery();
                if (a <= 0)
                {
                    SQLComm = new SqlCommand("insert into EmployeeImage (EmployeeID,EImage) values (@Employee,@EImage)", this.SQLConn);
                    EMP = new SqlParameter("@Employee", SqlDbType.Int, 4);
                    EMP.Value = employeeId;
                    SQLComm.Parameters.Add(EMP);
                    Img = new SqlParameter("@EImage", SqlDbType.Image, 2147483647);
                    Img.Value = image;
                    SQLComm.Parameters.Add(Img);

                    a = SQLComm.ExecuteNonQuery();
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "InsertImage");
            }

            this.DBDisconnect();
            return 0;
        }
        public int insertImagePrint(string EmployeeID, byte[] ProfileLeft, byte[] ProfileRight)
        {
            DBConnection();

            try
            {
                SQLComm = new SqlCommand("update EmployeePrint set ProfileRH = @EImageL,ProfileLH =@EImageR  where EmployeeID = @Employee", this.SQLConn);
                SqlParameter EMP = new SqlParameter("@Employee", SqlDbType.Int, 4);
                EMP.Value = EmployeeID;
                SQLComm.Parameters.Add(EMP);
                SqlParameter ImgL = new SqlParameter("@EImageL", SqlDbType.Image, 2147483647);
                ImgL.Value = ProfileLeft;
                SQLComm.Parameters.Add(ImgL);
                SqlParameter ImgR = new SqlParameter("@EImageR", SqlDbType.Image, 2147483647);
                ImgR.Value = ProfileRight;
                SQLComm.Parameters.Add(ImgR);
                int a = SQLComm.ExecuteNonQuery();
                if (a <= 0)
                {
                    SQLComm = new SqlCommand("insert into EmployeePrint (EmployeeID,ProfileRH,ProfileLH,FingerNoRH,FingerNoLH) values (@Employee,@EImageR,@EImageL,'2','7')", this.SQLConn);
                    EMP = new SqlParameter("@Employee", SqlDbType.Int, 4);
                    EMP.Value = EmployeeID;
                    SQLComm.Parameters.Add(EMP);
                    ImgL = new SqlParameter("@EImageL", SqlDbType.Image, 2147483647);
                    ImgL.Value = ProfileLeft;
                    SQLComm.Parameters.Add(ImgL);
                    ImgR = new SqlParameter("@EImageR", SqlDbType.Image, 2147483647);
                    ImgR.Value = ProfileRight;
                    SQLComm.Parameters.Add(ImgR);
                    a = SQLComm.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                string str = "" + e;
            }
            this.DBDisconnect();
            return 0;
        }
        public int InsertImageGlobal(string TableName, string IDField, string ImageField, string ID, byte[] image)
        {
            DBConnection();

            try
            {
                SQLComm = new SqlCommand("update " + TableName + " set " + ImageField + "= @Img where " + IDField + " = @ID", this.SQLConn);
                SqlParameter EMP = new SqlParameter("@ID", SqlDbType.Int, 4);
                EMP.Value = ID;
                SQLComm.Parameters.Add(EMP);
                SqlParameter Img = new SqlParameter("@Img", SqlDbType.Image, 2147483647);
                Img.Value = image;
                SQLComm.Parameters.Add(Img);
                int a = SQLComm.ExecuteNonQuery();
                if (a <= 0)
                {
                    SQLComm = new SqlCommand("insert into " + TableName + " (" + IDField + "," + ImageField + ") values (@ID,@Ing)", this.SQLConn);
                    EMP = new SqlParameter("@ID", SqlDbType.Int, 4);
                    EMP.Value = ID;
                    SQLComm.Parameters.Add(EMP);
                    Img = new SqlParameter("@Img", SqlDbType.Image, 2147483647);
                    Img.Value = image;
                    SQLComm.Parameters.Add(Img);

                    a = SQLComm.ExecuteNonQuery();
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "InsertImage");
            }

            this.DBDisconnect();
            return 0;
        }

        public int InsertImageGlobalNew(string TableName, string IDField, string ImageField, string ID, byte[] image)
        {
            DBConnection();

            try
            {
                int a = -1;
                if (ID != "-1")
                {
                    SQLComm = new SqlCommand("update " + TableName + " set " + ImageField + "= @Img where " + IDField + " = @ID", this.SQLConn);
                    SqlParameter EMP = new SqlParameter("@ID", SqlDbType.Int, 4);
                    EMP.Value = ID;
                    SQLComm.Parameters.Add(EMP);
                    SqlParameter Img = new SqlParameter("@Img", SqlDbType.Image, 2147483647);
                    Img.Value = image;
                    SQLComm.Parameters.Add(Img);
                    a = SQLComm.ExecuteNonQuery();
                }
                if (a <= 0)
                {
                    SQLComm = new SqlCommand("insert into " + TableName + " (" + ImageField + ") values (@Img)", this.SQLConn);
                    SqlParameter Img = new SqlParameter("@Img", SqlDbType.Image, 2147483647);
                    Img.Value = image;
                    SQLComm.Parameters.Add(Img);

                    a = SQLComm.ExecuteNonQuery();
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "InsertImage");
            }

            this.DBDisconnect();
            return 0;
        }

        public int InsertReport(string ReportName, string Extension, byte[] image, int UserID, string Email, int RepID)
        {
            int a = 0;
            DBConnection();

            try
            {
                string FileName = ReportName + DateTime.Now.ToString("ddMMMyyyyHHmm") + "." + Extension;
                SQLComm = new SqlCommand("insert into ReportDocument (FileName,ReportDocument,FileExtension,ReportDate,ReportName,OutputStatus,ReportDisplayName,UserID,MailTo,RepID) " +
                    "values ('" + FileName + "',@Img,'" + Extension + "','" + DateTime.Now.ToString("yyyy-MMM-dd HH:mm") + "','" + ReportName + "',0,'" + ReportName + "'," + UserID + ",'" + Email + "'," + RepID + ")", this.SQLConn);
                SqlParameter Img = new SqlParameter("@Img", SqlDbType.Image, 2147483647);
                Img.Value = image;
                SQLComm.Parameters.Add(Img);

                a = SQLComm.ExecuteNonQuery();
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "InsertImage");
            }

            this.DBDisconnect();
            return a;
        }

        public int InsertImageCard(string cardId, byte[] image, string Description)
        {
            DBConnection();

            try
            {
                SQLComm = new SqlCommand("update CardImages set Image = @EImage where ImageID = @Employee", this.SQLConn);
                SqlParameter EMP = new SqlParameter("@Employee", SqlDbType.Int, 4);
                EMP.Value = cardId;
                SQLComm.Parameters.Add(EMP);
                SqlParameter Img = new SqlParameter("@EImage", SqlDbType.Image, 2147483647);
                Img.Value = image;
                SQLComm.Parameters.Add(Img);
                int a = SQLComm.ExecuteNonQuery();
                if (a <= 0)
                {
                    SQLComm = new SqlCommand("insert into  CardImages (Description,Image) values (@Employee,@EImage)", this.SQLConn);
                    EMP = new SqlParameter("@Employee", SqlDbType.VarChar, 50);
                    EMP.Value = Description;
                    SQLComm.Parameters.Add(EMP);
                    Img = new SqlParameter("@EImage", SqlDbType.Image, 2147483647);
                    Img.Value = image;
                    SQLComm.Parameters.Add(Img);

                    a = SQLComm.ExecuteNonQuery();
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "InsertImageCard");
            }

            this.DBDisconnect();
            return 0;
        }

        public int InsertImagePain(int AssesmentId, byte[] image)
        {
            DBConnection();

            try
            {
                SQLComm = new SqlCommand("update AssesmentImage set AssesmentImage = @AImage where AssesmentID = @AssesmentID", this.SQLConn);
                SqlParameter EMP = new SqlParameter("@AssesmentID", SqlDbType.Int, 4);
                EMP.Value = AssesmentId;
                SQLComm.Parameters.Add(EMP);
                SqlParameter Img = new SqlParameter("@AImage", SqlDbType.Image, 2147483647);
                Img.Value = image;
                SQLComm.Parameters.Add(Img);
                int a = SQLComm.ExecuteNonQuery();
                if (a <= 0)
                {
                    SQLComm = new SqlCommand("insert into AssesmentImage (AssesmentID,AssesmentImage) values (@AssesmentID,@AImage)", this.SQLConn);
                    EMP = new SqlParameter("@AssesmentID", SqlDbType.Int, 4);
                    EMP.Value = AssesmentId;
                    SQLComm.Parameters.Add(EMP);
                    Img = new SqlParameter("@AImage", SqlDbType.Image, 2147483647);
                    Img.Value = image;
                    SQLComm.Parameters.Add(Img);

                    a = SQLComm.ExecuteNonQuery();
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "InsertImagePain");
            }

            this.DBDisconnect();
            return 0;
        }

        /// <summary>
        /// Batch Insert Used to insert a table into the database
        /// Columns creared as varchar(100)
        /// </summary>
        /// <param name="dt">DataTable containing the records to be inserted</param>
        /// <param name="dbTable">Name of Table to be created</param>
        /// <returns>bool status </returns>
        public bool BatchInsert(DataTable dt, string dbTable)
        {
            if (dt == null)
                return true;
            if (!DBConnection())
                return false;
            try
            {
                using (SqlBulkCopy bcp =
                    new SqlBulkCopy(SQLConn))
                {
                    string SQL = "if not exists(select * from dbo.sysobjects where Name = '" + dbTable + "') " +
                                "begin " +
                        "create Table " + dbTable + " (";
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        if (i > 0)
                            SQL = SQL + ",";

                        SQL = SQL + "[" + dt.Columns[i].ColumnName + "]" + " nvarchar (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL";
                    }
                    SQL = SQL + ") end ";

                    SQLComm.CommandText = SQL;
                    SQLComm.ExecuteNonQuery();
                    bcp.BulkCopyTimeout = 600;
                    bcp.DestinationTableName = dbTable;
                    // Write from the source to
                    // the destination.
                    bcp.WriteToServer(dt);
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Batch Insert Error" + x, "BatchInsert");
            }
            //this.Disconnect = true;
            //this.DBDiscon();
            return true;
        }

        public bool BatchInsertType(DataTable dt, string dbTable)
        {
            if (dt == null)
                return true;
            if (!DBConnection())
                return false;
            try
            {
                using (SqlBulkCopy bcp =
                    new SqlBulkCopy(SQLConn))
                {
                    string SQL = "if not exists(select * from dbo.sysobjects where Name = '" + dbTable + "') " +
                                "begin " +
                        "create Table " + dbTable + " (";
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        if (i > 0)
                            SQL = SQL + ",";
                        if (dt.Columns[i].DataType.Name == "DateTime")
                        {
                            SQL = SQL + "[" + dt.Columns[i].ColumnName + "]" + " [datetime] NULL";
                        }
                        else
                        {
                            SQL = SQL + "[" + dt.Columns[i].ColumnName + "]" + " nvarchar (500) COLLATE SQL_Latin1_General_CP1_CI_AS NULL";
                        }

                    }
                    SQL = SQL + ") end ";

                    SQLComm.CommandText = SQL;
                    SQLComm.ExecuteNonQuery();
                    bcp.BulkCopyTimeout = 600;
                    bcp.DestinationTableName = dbTable;
                    // Write from the source to
                    // the destination.
                    bcp.WriteToServer(dt);
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Batch Insert Error" + x, "BatchInsert");
            }
            //this.Disconnect = true;
            //this.DBDiscon();
            return true;
        }

        /// <summary>
        /// Batch Insert Used to insert a table into the database
        /// CreateTmpTable is the sql command to create the temporary table
        /// </summary>
        /// <param name="dt">DataTable containing the records to be inserted</param>
        /// <param name="dbTable">Name of Table to be created</param>
        ///  <param name="CreateTmpTable">SQL command to create the TMP Table</param>
        /// <returns>bool status </returns>
        public bool BatchInsertNew(DataTable dt, string dbTable, string CreateTmpTable)
        {
            if (dt == null)
                return true;
            if (!DBConnection())
                return false;
            try
            {
                using (SqlBulkCopy bcp =
                    new SqlBulkCopy(SQLConn))
                {
                    string SQL = CreateTmpTable;

                    SQLComm.CommandText = SQL;
                    SQLComm.ExecuteNonQuery();
                    bcp.BulkCopyTimeout = 600;
                    bcp.DestinationTableName = dbTable;
                    // Write from the source to
                    // the destination.
                    bcp.WriteToServer(dt);
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Batch Insert Error" + x, "BatchInsertNew");
            }
            //this.Disconnect = true;
            //this.DBDiscon();
            return true;
        }

        public int InsertImageEmployee(string employee, byte[] image)
        {
            DBConnection();

            try
            {
                SQLComm = new SqlCommand("update EmployeeImage set EImage = @EImage,Status = '0' where EmployeeID = @Employe", this.SQLConn);
                SqlParameter EMP = new SqlParameter("@Employe", SqlDbType.VarChar, 50);
                EMP.Value = employee;
                SQLComm.Parameters.Add(EMP);
                SqlParameter Img = new SqlParameter("@EImage", SqlDbType.Image, 2147483647);
                Img.Value = image;
                SQLComm.Parameters.Add(Img);
                int a = SQLComm.ExecuteNonQuery();
                if (a <= 0)
                {
                    SQLComm = new SqlCommand("insert into EmployeeImage (EmployeeID,EImage,Status) values (@Employe,@EImage,'0')", this.SQLConn);
                    EMP = new SqlParameter("@Employe", SqlDbType.VarChar, 50);
                    EMP.Value = employee;
                    SQLComm.Parameters.Add(EMP);
                    Img = new SqlParameter("@EImage", SqlDbType.Image, 2147483647);
                    Img.Value = image;
                    SQLComm.Parameters.Add(Img);

                    a = SQLComm.ExecuteNonQuery();
                }
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "InsertImageEmployee");
            }

            this.DBDisconnect();
            return 0;
        }

        public int SqlExecuteStoredProc(string Sp_Name, string SapParm1, string SapParm2, string SapParm3, string SapParm4, string SapParm5, string SapParm6, string SapParm7, string SapParm8, string SapParm9, string SapParm10)
        {
            DBConnection();

            try
            {
                SQLComm = new SqlCommand(Sp_Name, this.SQLConn);
                SQLComm.CommandType = CommandType.StoredProcedure;
                SqlParameter Parm1 = new SqlParameter("@SapParm1", SqlDbType.VarChar, 50);
                Parm1.Value = SapParm1;
                SQLComm.Parameters.Add(Parm1);
                SqlParameter Parm2 = new SqlParameter("@SapParm2", SqlDbType.VarChar, 50);
                Parm2.Value = SapParm2;
                SQLComm.Parameters.Add(Parm2);
                SqlParameter Parm3 = new SqlParameter("@SapParm3", SqlDbType.VarChar, 50);
                Parm3.Value = SapParm3;
                SQLComm.Parameters.Add(Parm3);
                SqlParameter Parm4 = new SqlParameter("@SapParm4", SqlDbType.VarChar, 50);
                Parm4.Value = SapParm4;
                SQLComm.Parameters.Add(Parm4);
                SqlParameter Parm5 = new SqlParameter("@SapParm5", SqlDbType.VarChar, 50);
                Parm5.Value = SapParm5;
                SQLComm.Parameters.Add(Parm5);
                SqlParameter Parm6 = new SqlParameter("@SapParm6", SqlDbType.VarChar, 50);
                Parm6.Value = SapParm6;
                SQLComm.Parameters.Add(Parm6);
                SqlParameter Parm7 = new SqlParameter("@SapParm7", SqlDbType.VarChar, 50);
                Parm7.Value = SapParm7;
                SQLComm.Parameters.Add(Parm7);
                SqlParameter Parm8 = new SqlParameter("@SapParm8", SqlDbType.VarChar, 50);
                Parm8.Value = SapParm8;
                SQLComm.Parameters.Add(Parm8);
                SqlParameter Parm9 = new SqlParameter("@SapParm9", SqlDbType.VarChar, 50);
                Parm9.Value = SapParm9;
                SQLComm.Parameters.Add(Parm9);
                SqlParameter Parm10 = new SqlParameter("@SapParm10", SqlDbType.VarChar, 50);
                Parm10.Value = SapParm10;
                SQLComm.Parameters.Add(Parm10);

                int a = SQLComm.ExecuteNonQuery();
            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "RunStoredProcedure");
            }

            this.DBDisconnect();
            return 0;
        }

        public int InsertImageStaging(string employeeId, byte[] image, string modifyDate, string status, string origId, string remoteId)
        {
            DBConnection();

            int cnt = 0;

            try
            {
                SQLComm = new SqlCommand("insert into EmployeeImage (EmployeeID,EImage,ModifyDate,Status,OrigID,remoteid) values (@Employee,@EImage,@ModifyDate,@Status,@OrigID,@remoteid)", this.SQLConn);
                SqlParameter EMP = new SqlParameter("@Employee", SqlDbType.Int, 4);
                EMP.Value = employeeId;
                SQLComm.Parameters.Add(EMP);
                SqlParameter Img = new SqlParameter("@EImage", SqlDbType.Image, 2147483647);
                Img.Value = image;

                SqlParameter MD = new SqlParameter("@ModifyDate", SqlDbType.DateTime, 4);
                MD.Value = modifyDate;
                SQLComm.Parameters.Add(MD);

                SqlParameter ST = new SqlParameter("@Status", SqlDbType.VarChar, 4);
                ST.Value = status;
                SQLComm.Parameters.Add(ST);

                SqlParameter OI = new SqlParameter("@OrigID", SqlDbType.Int, 4);
                OI.Value = origId;
                SQLComm.Parameters.Add(OI);

                SqlParameter RI = new SqlParameter("@remoteid", SqlDbType.Int, 4);
                RI.Value = remoteId;
                SQLComm.Parameters.Add(RI);

                SQLComm.Parameters.Add(Img);
                cnt = SQLComm.ExecuteNonQuery();

            }
            catch (Exception x)
            {
                TraceNew.WriteLine("Query Error" + x, "InsertImage");
            }

            this.DBDisconnect();
            return cnt;
        }

        #endregion
        # region Dispose Functions

        /// <summary>
        /// Dispose Functions
        /// </summary>
        // Pointer to an external unmanaged resource.
        //        private IntPtr handle;
        // Other managed resource this class uses.
        private Component component = new Component();

        // Track whether Dispose has been called.
        private bool disposed = false;

        // Implement IDisposable.
        // Do not make this method virtual.
        // A derived class should not be able to override this method.
        public void Dispose()
        {
            Dispose(true);
            // This object will be cleaned up by the Dispose method.
            // Therefore, you should call GC.SupressFinalize to
            // take this object off the finalization queue
            // and prevent finalization code for this object
            // from executing a second time.
            GC.SuppressFinalize(this);
        }

        // Dispose(bool disposing) executes in two distinct scenarios.
        // If disposing equals true, the method has been called directly
        // or indirectly by a user's code. Managed and unmanaged resources
        // can be disposed.
        // If disposing equals false, the method has been called by the
        // runtime from inside the finalizer and you should not reference
        // other objects. Only unmanaged resources can be disposed.
        private void Dispose(bool disposing)
        {
            // Check to see if Dispose has already been called.
            if (!this.disposed)
            {
                // If disposing equals true, dispose all managed
                // and unmanaged resources.
                if (disposing)
                {
                    if (SQLComm != null)
                        SQLComm.Dispose();
                    if (SQLConn != null)
                        SQLConn.Dispose();
                    component.Dispose();
                }

                // Call the appropriate methods to clean up
                // unmanaged resources here.
                // If disposing is false,
                // only the following code is executed.

                // CloseHandle(handle);
                //  handle = IntPtr.Zero;
            }
            disposed = true;
        }

        // Use interop to call the method necessary
        // to clean up the unmanaged resource.
        //   [System.Runtime.InteropServices.DllImport("Kernel32")]

        //     private extern static Boolean CloseHandle(IntPtr handle);

        // Use C# destructor syntax for finalization code.
        // This destructor will run only if the Dispose method
        // does not get called.
        // It gives your base class the opportunity to finalize.
        // Do not provide destructors in types derived from this class.
        ~SqlCommands()
        {
            // Do not re-create Dispose clean-up code here.
            // Calling Dispose(false) is optimal in terms of
            // readability and maintainability.
            Dispose(false);

            this.DBDisconnect();
        }

        #endregion
    }
}